
CREATE POLICY "Users read own renders" ON storage.objects FOR SELECT TO authenticated
USING (bucket_id = 'renders' AND auth.uid()::text = (storage.foldername(name))[1]);
CREATE POLICY "Users upload own renders" ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'renders' AND auth.uid()::text = (storage.foldername(name))[1]);
CREATE POLICY "Users update own renders" ON storage.objects FOR UPDATE TO authenticated
USING (bucket_id = 'renders' AND auth.uid()::text = (storage.foldername(name))[1]);
CREATE POLICY "Users delete own renders" ON storage.objects FOR DELETE TO authenticated
USING (bucket_id = 'renders' AND auth.uid()::text = (storage.foldername(name))[1]);
