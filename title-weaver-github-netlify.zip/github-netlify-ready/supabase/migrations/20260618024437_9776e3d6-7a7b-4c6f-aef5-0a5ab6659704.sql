
CREATE TABLE public.brand_kits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL DEFAULT 'My Brand Kit',
  primary_color text NOT NULL DEFAULT '#b6ff3b',
  background_color text NOT NULL DEFAULT '#0a0a0a',
  text_color text NOT NULL DEFAULT '#ffffff',
  heading_font text NOT NULL DEFAULT 'Bebas Neue',
  body_font text NOT NULL DEFAULT 'Space Grotesk',
  heading_font_url text,
  body_font_url text,
  heading_font_family_name text,
  body_font_family_name text,
  logo_url text,
  logo_position text NOT NULL DEFAULT 'top-right',
  logo_size integer NOT NULL DEFAULT 12,
  logo_opacity integer NOT NULL DEFAULT 90,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.brand_kits TO authenticated;
GRANT ALL ON public.brand_kits TO service_role;

ALTER TABLE public.brand_kits ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users manage their own brand kits"
  ON public.brand_kits FOR ALL
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE TRIGGER touch_brand_kits_updated_at
  BEFORE UPDATE ON public.brand_kits
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

ALTER TABLE public.projects
  ADD COLUMN brand_kit_id uuid REFERENCES public.brand_kits(id) ON DELETE SET NULL,
  ADD COLUMN export_resolution text NOT NULL DEFAULT '720p',
  ADD COLUMN mp4_url text;
