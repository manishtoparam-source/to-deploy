
-- profiles
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  name TEXT,
  email TEXT,
  plan_type TEXT NOT NULL DEFAULT 'free',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users manage their own profile" ON public.profiles FOR ALL USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, name, email)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'name', split_part(NEW.email, '@', 1)), NEW.email)
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- templates (public read)
CREATE TABLE public.templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  template_name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  category TEXT,
  thumbnail_url TEXT,
  background_style TEXT,
  animation_type TEXT,
  default_font TEXT,
  default_color TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  sort_order INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.templates TO anon, authenticated;
GRANT ALL ON public.templates TO service_role;
ALTER TABLE public.templates ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone reads active templates" ON public.templates FOR SELECT USING (is_active = true);

-- projects
CREATE TABLE public.projects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  project_name TEXT NOT NULL DEFAULT 'Untitled Project',
  chapter_label TEXT NOT NULL DEFAULT 'CHAPTER 03',
  main_title TEXT NOT NULL DEFAULT 'THE COLLAPSE',
  subtitle TEXT DEFAULT '',
  selected_style TEXT NOT NULL DEFAULT 'documentary-dark',
  duration INT NOT NULL DEFAULT 5,
  aspect_ratio TEXT NOT NULL DEFAULT '16:9',
  highlight_color TEXT NOT NULL DEFAULT '#b6ff3b',
  film_grain_enabled BOOLEAN NOT NULL DEFAULT true,
  camera_movement TEXT NOT NULL DEFAULT 'Slow Push In',
  text_size INT NOT NULL DEFAULT 80,
  background_intensity INT NOT NULL DEFAULT 70,
  preview_image_url TEXT,
  video_url TEXT,
  render_status TEXT NOT NULL DEFAULT 'draft',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.projects TO authenticated;
GRANT ALL ON public.projects TO service_role;
ALTER TABLE public.projects ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users manage their own projects" ON public.projects FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION public.touch_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$ LANGUAGE plpgsql SET search_path = public;
CREATE TRIGGER projects_touch_updated_at BEFORE UPDATE ON public.projects FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- render_jobs
CREATE TABLE public.render_jobs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID NOT NULL REFERENCES public.projects ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'pending',
  output_url TEXT,
  error_message TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  completed_at TIMESTAMPTZ
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.render_jobs TO authenticated;
GRANT ALL ON public.render_jobs TO service_role;
ALTER TABLE public.render_jobs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users manage their own render jobs" ON public.render_jobs FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- seed templates
INSERT INTO public.templates (template_name, slug, category, default_color, default_font, animation_type, background_style, sort_order) VALUES
('Documentary Dark', 'documentary-dark', 'cinematic', '#b6ff3b', 'Bebas Neue', 'slow-push-in', 'dark-investigative', 1),
('Newspaper', 'newspaper', 'editorial', '#111111', 'Bebas Neue', 'static', 'paper-print', 2),
('Retro VHS', 'retro-vhs', 'retro', '#ff2ea6', 'JetBrains Mono', 'glitch', 'vhs-scanlines', 3),
('Minimal Clean', 'minimal-clean', 'minimal', '#ffffff', 'Space Grotesk', 'fade-in', 'flat-dark', 4),
('Crime File', 'crime-file', 'documentary', '#e23b3b', 'Bebas Neue', 'slow-zoom', 'red-folder', 5),
('Cinematic Gold', 'cinematic-gold', 'cinematic', '#e7c46a', 'Bebas Neue', 'slow-push-in', 'gold-grain', 6),
('Glitch Cyber', 'glitch-cyber', 'cyber', '#00ffd0', 'JetBrains Mono', 'glitch', 'cyber-grid', 7),
('Archive Paper', 'archive-paper', 'editorial', '#c9a96a', 'Bebas Neue', 'static', 'archive-yellow', 8),
('Financial Crime', 'financial-crime', 'documentary', '#5cff8a', 'JetBrains Mono', 'data-flicker', 'data-terminal', 9),
('True Crime Board', 'true-crime-board', 'documentary', '#ff3b3b', 'Bebas Neue', 'slow-pan', 'corkboard-strings', 10);
