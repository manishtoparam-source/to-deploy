CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

CREATE TABLE public.custom_fonts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  family_name text NOT NULL,
  source_type text NOT NULL CHECK (source_type IN ('upload','file_url','css_url')),
  file_url text,
  css_url text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.custom_fonts TO authenticated;
GRANT ALL ON public.custom_fonts TO service_role;

ALTER TABLE public.custom_fonts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users manage own fonts" ON public.custom_fonts
  FOR ALL TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE TRIGGER update_custom_fonts_updated_at
  BEFORE UPDATE ON public.custom_fonts
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE INDEX custom_fonts_user_id_idx ON public.custom_fonts(user_id);