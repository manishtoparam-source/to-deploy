# Quick Start Commands

## Installation (First Time Only)

```bash
# 1. Install dependencies
npm install

# 2. Install Capacitor packages
npm install @capacitor/core @capacitor/cli @capacitor/android @capacitor/ios \
  @capacitor/splash-screen @capacitor/app @capacitor/keyboard @capacitor/status-bar

# 3. Initialize Capacitor
npx cap init

# 4. Build web assets
npm run build
```

## Android Setup (One Time)

```bash
# Add Android platform
npx cap add android

# Open Android Studio to complete setup
npx cap open android
```

## iOS Setup (One Time, Mac Only)

```bash
# Add iOS platform
npx cap add ios

# Open Xcode
npx cap open ios
```

## Development Workflow

```bash
# Watch mode (local development)
npm run dev

# Build for production
npm run build

# Sync changes to native projects
npx cap sync

# Open Android Studio
npx cap open android

# Open Xcode
npx cap open ios
```

## Android Build & Deploy

```bash
# Build release bundle for Play Store
cd android && ./gradlew bundleRelease

# Find output at:
# android/app/build/outputs/bundle/release/app-release.aab

# APK for testing (optional):
./gradlew assembleRelease

# Find output at:
# android/app/build/outputs/apk/release/app-release.apk
```

## iOS Build & Deploy

```bash
# In Xcode:
# 1. Select "Any iOS Device" or simulator
# 2. Product → Archive
# 3. Window → Organizer
# 4. Select archive → Distribute App → App Store Connect
```

## Helpful Commands

```bash
# Clear Android build cache
cd android && ./gradlew clean

# Verify Android setup
npx cap doctor

# Update native code from web build
npx cap sync --deployment

# Reset Capacitor (clean start)
rm -rf android ios
npx cap add android
npx cap add ios
```

## App Store URLs

- **Google Play**: https://play.google.com/console
- **App Store Connect**: https://appstoreconnect.apple.com
- **Google Play Developer Docs**: https://developer.android.com
- **Apple Developer Docs**: https://developer.apple.com

## Timeline Estimate

| Phase | Time |
|-------|------|
| Local setup | 30-45 min |
| Android build setup | 1-2 hours |
| iOS build setup | 1-2 hours |
| First submission | 2-3 days |
| App Store review | 1-3 days (Google), 1-5 days (Apple) |
| **Total** | **1-2 weeks** |

## Important Notes

⚠️ **Backup your keystore!**
```bash
# After creating keystore, backup immediately
cp android/app/title-weaver.keystore ~/Backups/
```

⚠️ **Never commit keystore to Git**
```bash
# Add to .gitignore
echo "*.keystore" >> .gitignore
echo "local.properties" >> .gitignore
```

✅ **Test on real devices** before submitting to stores

✅ **Keep version numbers consistent** across platforms

✅ **Update DEPLOYMENT_GUIDE.md** credentials section as you go
