# Title Weaver - App Store Deployment Package

This package contains everything you need to deploy Title Weaver to Google Play Store and Apple App Store.

## 📋 Contents

- **DEPLOYMENT_GUIDE.md** - Complete step-by-step guide (read this first!)
- **QUICK_START.md** - Copy-paste commands reference
- **capacitor.config.ts** - Capacitor configuration (already in your project)
- **package-capacitor-additions.json** - Capacitor dependencies to install

## 🚀 Getting Started (5 minutes)

### 1. Read the Guide
Start with **DEPLOYMENT_GUIDE.md** - it covers everything in detail.

### 2. Follow Quick Start
Use **QUICK_START.md** for the actual commands.

### 3. Install Capacitor
```bash
npm install @capacitor/core @capacitor/cli @capacitor/android @capacitor/ios \
  @capacitor/splash-screen @capacitor/app @capacitor/keyboard @capacitor/status-bar
```

### 4. Initialize
```bash
npx cap init
npm run build
```

### 5. Add Platforms
```bash
# Android
npx cap add android

# iOS (Mac only)
npx cap add ios
```

## 📋 Before You Start

You'll need:
- [ ] Node.js v16+ installed
- [ ] Google Play Developer account ($25)
- [ ] Apple Developer account ($99/year)
- [ ] Android Studio installed (for Android)
- [ ] Xcode installed (for iOS, Mac only)
- [ ] App icon (1024×1024 PNG)
- [ ] App screenshots (5-8 per platform)
- [ ] Privacy policy URL

## ⏱️ Timeline

| Step | Time |
|------|------|
| Setup Capacitor | 30 min |
| Android build | 2-3 hours |
| iOS build | 2-3 hours |
| Google Play submission | 2-4 hours |
| Apple App Store submission | 2-4 hours |
| Review & approval | 1-5 days |
| **Total** | **1-2 weeks** |

## 📱 Key Configuration

**App ID**: `com.titleweaver.app`
**App Name**: `Title Weaver`
**Web Directory**: `dist`

Change these in `capacitor.config.ts` if needed.

## 🆘 Troubleshooting

### "Command not found: npx"
→ Install Node.js from https://nodejs.org

### "Gradle build failed"
→ Run: `cd android && ./gradlew clean && ./gradlew bundleRelease`

### "Xcode archive failed"
→ Check: Xcode → Preferences → Accounts → Refresh

### "APK too large"
→ See: https://capacitorjs.com/docs/android/build-variants

## 📚 Documentation

- **Capacitor**: https://capacitorjs.com
- **Android Dev**: https://developer.android.com
- **Apple Dev**: https://developer.apple.com
- **Play Store**: https://support.google.com/googleplay
- **App Store**: https://help.apple.com/app-store-connect

## ✅ Submission Checklist

See **DEPLOYMENT_GUIDE.md** last section for full checklist.

Quick version:
- [ ] Builds without errors
- [ ] Tested on real device
- [ ] App icon added
- [ ] Screenshots ready
- [ ] Privacy policy URL ready
- [ ] Keystore backed up (Android)
- [ ] Version numbers set

## 🆙 For Future Updates

Each time you release a new version:
1. Update version number in `package.json`
2. Run `npm run build`
3. Run `npx cap sync`
4. Rebuild Android and iOS
5. Upload to respective stores

## 🔒 Security

⚠️ **Never commit keystore to Git:**
```bash
echo "*.keystore" >> .gitignore
echo "local.properties" >> .gitignore
git add .gitignore && git commit -m "Ignore keystore files"
```

⚠️ **Backup your keystore immediately:**
```bash
cp android/app/title-weaver.keystore ~/Backups/
# Keep in safe location - you can't recover it if lost!
```

## 📧 Support

If you get stuck:
1. Check DEPLOYMENT_GUIDE.md "Common Issues" section
2. Review official Capacitor docs: https://capacitorjs.com
3. Google the error message (99% of issues are documented)
4. Ask on Stack Overflow with tags: `capacitor`, `android`, `ios`

---

**Ready to deploy? Start with DEPLOYMENT_GUIDE.md!** 🚀
