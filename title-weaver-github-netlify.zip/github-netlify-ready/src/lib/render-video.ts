import { toCanvas, toPng } from "html-to-image";
import { cameraAt } from "./camera";
import type { CameraMovement } from "./templates";

export interface RenderResult {
  webmBlob: Blob;
  pngBlob: Blob;
  durationSec: number;
}

/**
 * Capture a DOM node as an animated WebM by rasterizing frames at ~24fps.
 * For MVP: we capture a high-res PNG once, then draw it onto a canvas with a
 * camera-movement transform driven by `cameraMove`. This keeps the WebM small
 * and deterministic while still producing a real animation.
 */
export async function renderTitleCardToWebM(opts: {
  node: HTMLElement;
  width: number;
  height: number;
  durationSec: number;
  camera: CameraMovement;
  onProgress?: (p: number) => void;
}): Promise<RenderResult> {
  const { node, width, height, durationSec, camera, onProgress } = opts;

  // PNG poster (high-res of the static card)
  const pngBlob = await nodeToBlob(node, width, height);
  const bitmap = await blobToImageBitmap(pngBlob);

  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d", { alpha: false })!;

  // pick MediaRecorder mime
  const mime = pickMime();
  const stream = (canvas as any).captureStream(30) as MediaStream;
  // Bitrate scales with pixel area (≈ 6 Mbps at 720p, 13 Mbps at 1080p, 50+ Mbps at 4K)
  const bitrate = Math.max(4_000_000, Math.min(80_000_000, Math.round((width * height) / 250)));
  const recorder = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: bitrate });
  const chunks: BlobPart[] = [];
  recorder.ondataavailable = (e) => { if (e.data.size) chunks.push(e.data); };

  const stopped = new Promise<void>((res) => (recorder.onstop = () => res()));
  recorder.start(100);

  const fps = 30;
  const totalFrames = Math.max(1, Math.floor(durationSec * fps));
  const start = performance.now();

  for (let i = 0; i < totalFrames; i++) {
    const target = start + (i / fps) * 1000;
    while (performance.now() < target) await sleep(2);
    const t = i / (totalFrames - 1 || 1);
    drawFrame(ctx, bitmap, width, height, camera, t);
    onProgress?.(t);
  }
  // hold last frame briefly
  await sleep(120);
  recorder.stop();
  await stopped;

  const webmBlob = new Blob(chunks, { type: mime });
  onProgress?.(1);
  return { webmBlob, pngBlob, durationSec };
}

function drawFrame(
  ctx: CanvasRenderingContext2D,
  img: ImageBitmap,
  w: number,
  h: number,
  camera: CameraMovement,
  t: number,
) {
  ctx.fillStyle = "#000";
  ctx.fillRect(0, 0, w, h);

  const f = cameraAt(camera, t);
  ctx.save();
  // Scale blur with resolution (frame.blur is at 1080p baseline)
  const blurPx = f.blur > 0 ? (f.blur * h) / 1080 : 0;
  ctx.filter = blurPx > 0 ? `blur(${blurPx}px)` : "none";
  ctx.translate(w / 2 + f.tx * w, h / 2 + f.ty * h);
  if (f.rotate) ctx.rotate((f.rotate * Math.PI) / 180);
  ctx.scale(f.scale, f.scale);
  ctx.drawImage(img, -w / 2, -h / 2, w, h);
  ctx.restore();
  ctx.filter = "none";

  // subtle vignette for cinematic feel
  const g = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.3, w / 2, h / 2, Math.max(w, h) * 0.7);
  g.addColorStop(0, "rgba(0,0,0,0)");
  g.addColorStop(1, "rgba(0,0,0,0.35)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, w, h);
}

async function nodeToBlob(node: HTMLElement, width: number, height: number): Promise<Blob> {
  const rect = node.getBoundingClientRect();
  // pixelRatio determines the source crispness — go as high as needed for 4K.
  const pixelRatio = Math.max(1, Math.min(4, width / rect.width));
  // Ensure fonts (including newly added custom faces) are ready before rasterizing.
  if (typeof document !== "undefined" && (document as any).fonts?.ready) {
    try { await (document as any).fonts.ready; } catch {}
  }
  const c = await toCanvas(node, {
    pixelRatio,
    cacheBust: true,
    backgroundColor: "#000",
    width: rect.width,
    height: rect.height,
  });
  // re-rasterize to exact target dimensions
  const out = document.createElement("canvas");
  out.width = width;
  out.height = height;
  const ctx = out.getContext("2d", { alpha: false })!;
  ctx.fillStyle = "#000";
  ctx.fillRect(0, 0, width, height);
  ctx.drawImage(c, 0, 0, width, height);
  return new Promise<Blob>((res) => out.toBlob((b) => res(b!), "image/png", 0.95));
}

async function blobToImageBitmap(b: Blob): Promise<ImageBitmap> {
  if ("createImageBitmap" in window) return createImageBitmap(b);
  const url = URL.createObjectURL(b);
  const img = new Image();
  await new Promise((r, j) => { img.onload = r; img.onerror = j; img.src = url; });
  return (await createImageBitmap(img)) as ImageBitmap;
}

function pickMime(): string {
  const candidates = [
    "video/webm;codecs=vp9",
    "video/webm;codecs=vp8",
    "video/webm",
  ];
  for (const m of candidates) {
    if (typeof MediaRecorder !== "undefined" && MediaRecorder.isTypeSupported(m)) return m;
  }
  return "video/webm";
}

function sleep(ms: number) { return new Promise((r) => setTimeout(r, ms)); }

export async function nodeToPngDataUrl(node: HTMLElement): Promise<string> {
  return toPng(node, { cacheBust: true, backgroundColor: "#000", pixelRatio: 2 });
}