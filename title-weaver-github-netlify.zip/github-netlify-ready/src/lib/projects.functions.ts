import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const projectInput = z.object({
  project_name: z.string().min(1).max(120).optional(),
  chapter_label: z.string().max(80),
  main_title: z.string().max(120),
  subtitle: z.string().max(160).optional().default(""),
  selected_style: z.string().max(60),
  duration: z.number().int().min(1).max(60),
  aspect_ratio: z.enum(["16:9", "9:16", "1:1", "4:5"]),
  highlight_color: z.string().regex(/^#[0-9a-fA-F]{3,8}$/),
  film_grain_enabled: z.boolean(),
  camera_movement: z.string().max(60),
  text_size: z.number().int().min(20).max(200),
  background_intensity: z.number().int().min(0).max(100),
  brand_kit_id: z.string().uuid().nullable().optional(),
  export_resolution: z.enum(["720p", "1080p", "4K"]).optional(),
  custom_background_url: z.string().url().nullable().optional(),
  title_motion: z.string().max(60).optional(),
});

export const listProjects = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("projects")
      .select("*")
      .order("updated_at", { ascending: false });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const getProject = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { id: string }) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { data: row, error } = await context.supabase
      .from("projects").select("*").eq("id", data.id).maybeSingle();
    if (error) throw new Error(error.message);
    if (!row) throw new Error("Project not found");
    return row;
  });

export const createProject = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => projectInput.partial().parse(input ?? {}))
  .handler(async ({ data, context }) => {
    const { data: row, error } = await context.supabase
      .from("projects")
      .insert({ ...data, user_id: context.userId })
      .select("*").single();
    if (error) throw new Error(error.message);
    return row;
  });

export const updateProject = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ id: z.string().uuid(), patch: projectInput.partial().extend({
      preview_image_url: z.string().url().optional(),
      video_url: z.string().url().optional(),
      mp4_url: z.string().url().optional(),
      render_status: z.string().optional(),
    }) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { data: row, error } = await context.supabase
      .from("projects").update(data.patch).eq("id", data.id).select("*").single();
    if (error) throw new Error(error.message);
    return row;
  });

export const deleteProject = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("projects").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const duplicateProject = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { data: src, error: e1 } = await context.supabase
      .from("projects").select("*").eq("id", data.id).single();
    if (e1 || !src) throw new Error(e1?.message ?? "Not found");
    const { id, created_at, updated_at, ...rest } = src as any;
    const { data: row, error } = await context.supabase
      .from("projects").insert({ ...rest, project_name: `${rest.project_name} (copy)` })
      .select("*").single();
    if (error) throw new Error(error.message);
    return row;
  });

export const createRenderJob = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ project_id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { data: row, error } = await context.supabase
      .from("render_jobs")
      .insert({ project_id: data.project_id, user_id: context.userId, status: "rendering" })
      .select("*").single();
    if (error) throw new Error(error.message);
    return row;
  });

export const completeRenderJob = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({
      job_id: z.string().uuid(),
      project_id: z.string().uuid(),
      video_url: z.string(),
      preview_image_url: z.string(),
    }).parse(input),
  )
  .handler(async ({ data, context }) => {
    await context.supabase.from("render_jobs").update({
      status: "completed", output_url: data.video_url, completed_at: new Date().toISOString(),
    }).eq("id", data.job_id);
    await context.supabase.from("projects").update({
      video_url: data.video_url,
      preview_image_url: data.preview_image_url,
      render_status: "completed",
    }).eq("id", data.project_id);
    return { ok: true };
  });

export const failRenderJob = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ job_id: z.string().uuid(), message: z.string().max(500) }).parse(input))
  .handler(async ({ data, context }) => {
    await context.supabase.from("render_jobs").update({
      status: "failed", error_message: data.message, completed_at: new Date().toISOString(),
    }).eq("id", data.job_id);
    return { ok: true };
  });