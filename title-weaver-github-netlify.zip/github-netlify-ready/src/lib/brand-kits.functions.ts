import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const brandKitInput = z.object({
  name: z.string().min(1).max(80),
  primary_color: z.string().regex(/^#[0-9a-fA-F]{3,8}$/),
  background_color: z.string().regex(/^#[0-9a-fA-F]{3,8}$/),
  text_color: z.string().regex(/^#[0-9a-fA-F]{3,8}$/),
  heading_font: z.string().min(1).max(80),
  body_font: z.string().min(1).max(80),
  heading_font_url: z.string().url().nullable().optional(),
  body_font_url: z.string().url().nullable().optional(),
  heading_font_family_name: z.string().max(80).nullable().optional(),
  body_font_family_name: z.string().max(80).nullable().optional(),
  logo_url: z.string().url().nullable().optional(),
  logo_position: z.enum(["top-left", "top-right", "bottom-left", "bottom-right"]),
  logo_size: z.number().int().min(4).max(40),
  logo_opacity: z.number().int().min(10).max(100),
});

export const listBrandKits = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("brand_kits")
      .select("*")
      .order("updated_at", { ascending: false });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const createBrandKit = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => brandKitInput.partial().parse(input ?? {}))
  .handler(async ({ data, context }) => {
    const { data: row, error } = await context.supabase
      .from("brand_kits")
      .insert({ ...data, user_id: context.userId } as any)
      .select("*").single();
    if (error) throw new Error(error.message);
    return row;
  });

export const updateBrandKit = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ id: z.string().uuid(), patch: brandKitInput.partial() }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { data: row, error } = await context.supabase
      .from("brand_kits").update(data.patch).eq("id", data.id).select("*").single();
    if (error) throw new Error(error.message);
    return row;
  });

export const deleteBrandKit = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("brand_kits").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });