import documentaryDarkBg from "@/assets/templates/documentary-dark.jpg";
import newspaperBg from "@/assets/templates/newspaper.jpg";
import retroVhsBg from "@/assets/templates/retro-vhs.jpg";
import minimalCleanBg from "@/assets/templates/minimal-clean.jpg";
import crimeFileBg from "@/assets/templates/crime-file.jpg";
import cinematicGoldBg from "@/assets/templates/cinematic-gold.jpg";
import glitchCyberBg from "@/assets/templates/glitch-cyber.jpg";
import archiveFilmBg from "@/assets/templates/archive-film.jpg";
import courtDocumentBg from "@/assets/templates/court-document.jpg";
import breakingNewsBg from "@/assets/templates/breaking-news.jpg";

export type TemplateSlug =
  | "documentary-dark"
  | "newspaper"
  | "retro-vhs"
  | "minimal-clean"
  | "crime-file"
  | "cinematic-gold"
  | "glitch-cyber"
  | "archive-film"
  | "court-document"
  | "breaking-news";

export interface TemplateMeta {
  slug: TemplateSlug;
  name: string;
  category: string;
  accent: string;
  font: string;
  /** Cinematic background plate */
  background: string;
  /** Light background → use dark text */
  light?: boolean;
}

export const TEMPLATES: TemplateMeta[] = [
  { slug: "documentary-dark", name: "Documentary Dark", category: "Cinematic", accent: "#b6ff3b", font: "Bebas Neue", background: documentaryDarkBg },
  { slug: "newspaper", name: "Newspaper", category: "Editorial", accent: "#111111", font: "Bebas Neue", background: newspaperBg, light: true },
  { slug: "retro-vhs", name: "Retro VHS", category: "Retro", accent: "#ff2ea6", font: "JetBrains Mono", background: retroVhsBg },
  { slug: "minimal-clean", name: "Minimal Clean", category: "Minimal", accent: "#111111", font: "Space Grotesk", background: minimalCleanBg, light: true },
  { slug: "crime-file", name: "Crime File", category: "Documentary", accent: "#e23b3b", font: "Bebas Neue", background: crimeFileBg },
  { slug: "cinematic-gold", name: "Cinematic Gold", category: "Cinematic", accent: "#e7c46a", font: "Bebas Neue", background: cinematicGoldBg },
  { slug: "glitch-cyber", name: "Glitch Cyber", category: "Cyber", accent: "#00ffd0", font: "JetBrains Mono", background: glitchCyberBg },
  { slug: "archive-film", name: "Archive Film", category: "Editorial", accent: "#f5e8c8", font: "Bebas Neue", background: archiveFilmBg },
  { slug: "court-document", name: "Court Document", category: "Documentary", accent: "#b91c1c", font: "Bebas Neue", background: courtDocumentBg, light: true },
  { slug: "breaking-news", name: "Breaking News", category: "News", accent: "#ef2b2b", font: "Bebas Neue", background: breakingNewsBg },
];

export const ASPECT_RATIOS = ["16:9", "9:16", "1:1", "4:5"] as const;
export type AspectRatio = (typeof ASPECT_RATIOS)[number];

export const CAMERA_MOVEMENTS = [
  "Slow Push In",
  "Slow Pull Out",
  "Left Pan",
  "Right Pan",
  "Crane Up",
  "Crane Down",
  "Vertigo Dolly",
  "Orbit",
  "Parallax Drift",
  "Whip Pan Right",
  "Rack Focus",
  "Earthquake Shake",
  "Handheld Documentary",
  "Static",
] as const;
export type CameraMovement = (typeof CAMERA_MOVEMENTS)[number];

export const TITLE_MOTIONS = [
  "None",
  "Slow Push-In",
  "Letter Fade-In",
  "Typewriter Reveal",
  "Stamp Reveal",
  "Glitch Flicker",
  "Light Sweep",
  "Newspaper Ink Reveal",
  "Dust Explosion Reveal",
  "Camera Pan Across Text",
  "Word Scale Pop",
] as const;
export type TitleMotionEffect = (typeof TITLE_MOTIONS)[number];

export const DURATIONS = [3, 5, 7, 10] as const;

export const EXPORT_RESOLUTIONS = ["720p", "1080p", "4K"] as const;
export type ExportResolution = (typeof EXPORT_RESOLUTIONS)[number];

export function aspectToWH(a: AspectRatio): { w: number; h: number } {
  switch (a) {
    case "16:9": return { w: 1920, h: 1080 };
    case "9:16": return { w: 1080, h: 1920 };
    case "1:1": return { w: 1080, h: 1080 };
    case "4:5": return { w: 1080, h: 1350 };
  }
}

export function aspectStyle(a: AspectRatio): string {
  return a.replace(":", " / ");
}

export function exportDimensions(a: AspectRatio, res: ExportResolution): { w: number; h: number } {
  const base = aspectToWH(a); // 1080p baseline
  const factor = res === "720p" ? 720 / 1080 : res === "1080p" ? 1 : 2;
  return { w: Math.round(base.w * factor), h: Math.round(base.h * factor) };
}