/**
 * Curated Google Fonts list for the brand kit picker.
 * Loaded on demand by injecting a <link> tag.
 */
export const GOOGLE_FONTS = [
  "Bebas Neue",
  "Space Grotesk",
  "Inter",
  "Poppins",
  "Montserrat",
  "Oswald",
  "Anton",
  "Archivo Black",
  "Playfair Display",
  "Cormorant Garamond",
  "DM Serif Display",
  "Lora",
  "Roboto",
  "Roboto Condensed",
  "Barlow",
  "Barlow Condensed",
  "Manrope",
  "Outfit",
  "Figtree",
  "Plus Jakarta Sans",
  "JetBrains Mono",
  "IBM Plex Mono",
  "Space Mono",
  "Syne",
  "Unbounded",
  "Big Shoulders Display",
  "Rubik Mono One",
  "Major Mono Display",
] as const;

export type GoogleFont = (typeof GOOGLE_FONTS)[number];

const loaded = new Set<string>();

export function loadGoogleFont(family: string) {
  if (typeof document === "undefined") return;
  if (loaded.has(family)) return;
  loaded.add(family);
  const id = `gf-${family.replace(/\s+/g, "-").toLowerCase()}`;
  if (document.getElementById(id)) return;
  const link = document.createElement("link");
  link.id = id;
  link.rel = "stylesheet";
  link.href = `https://fonts.googleapis.com/css2?family=${encodeURIComponent(family)}:wght@300;400;500;600;700&display=swap`;
  document.head.appendChild(link);
}

const customLoaded = new Map<string, Promise<void>>();

/** Register an uploaded font file as a FontFace under `familyName`. */
export function loadCustomFont(familyName: string, url: string): Promise<void> {
  if (typeof document === "undefined") return Promise.resolve();
  const key = `${familyName}|${url}`;
  const existing = customLoaded.get(key);
  if (existing) return existing;
  const p = (async () => {
    try {
      const face = new FontFace(familyName, `url("${url}")`);
      const loaded = await face.load();
      (document as any).fonts.add(loaded);
    } catch (e) {
      console.warn("Custom font load failed", familyName, e);
    }
  })();
  customLoaded.set(key, p);
  return p;
}

const cssLoaded = new Set<string>();

/** Inject a remote stylesheet URL (e.g. Google Fonts CSS, Adobe Edge, Fontshare). */
export function loadFontStylesheet(url: string) {
  if (typeof document === "undefined") return;
  if (cssLoaded.has(url)) return;
  cssLoaded.add(url);
  const link = document.createElement("link");
  link.rel = "stylesheet";
  link.href = url;
  link.crossOrigin = "anonymous";
  document.head.appendChild(link);
}

export type SavedFontRow = {
  id: string;
  name: string;
  family_name: string;
  source_type: "upload" | "file_url" | "css_url";
  file_url: string | null;
  css_url: string | null;
};

/** Load any saved custom font row so its family_name becomes usable. */
export function loadSavedFont(font: SavedFontRow) {
  if (font.source_type === "css_url" && font.css_url) {
    loadFontStylesheet(font.css_url);
  } else if (font.file_url) {
    void loadCustomFont(font.family_name, font.file_url);
  }
}