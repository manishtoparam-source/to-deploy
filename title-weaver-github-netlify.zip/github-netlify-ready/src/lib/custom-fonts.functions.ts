import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const fontInput = z.object({
  name: z.string().min(1).max(80),
  family_name: z.string().min(1).max(80),
  source_type: z.enum(["upload", "file_url", "css_url"]),
  file_url: z.string().url().nullable().optional(),
  css_url: z.string().url().nullable().optional(),
});

export const listCustomFonts = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("custom_fonts")
      .select("*")
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const createCustomFont = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => fontInput.parse(input))
  .handler(async ({ data, context }) => {
    const { data: row, error } = await context.supabase
      .from("custom_fonts")
      .insert({ ...data, user_id: context.userId } as any)
      .select("*").single();
    if (error) throw new Error(error.message);
    return row;
  });

export const deleteCustomFont = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("custom_fonts").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });