import type { CameraMovement } from "./templates";

export interface CameraFrame {
  scale: number;
  tx: number; // fraction of width
  ty: number; // fraction of height
  rotate: number; // degrees
  blur: number; // px (at 1080p baseline)
}

/** Returns a deterministic camera transform at progress t in [0,1]. */
export function cameraAt(move: CameraMovement, t: number): CameraFrame {
  const z = { scale: 1, tx: 0, ty: 0, rotate: 0, blur: 0 };
  switch (move) {
    case "Slow Push In":
      return { ...z, scale: 1.02 + 0.10 * t };
    case "Slow Pull Out":
      return { ...z, scale: 1.15 - 0.13 * t };
    case "Left Pan":
      return { ...z, scale: 1.06, tx: 0.025 - 0.05 * t };
    case "Right Pan":
      return { ...z, scale: 1.06, tx: -0.025 + 0.05 * t };
    case "Crane Up":
      return { ...z, scale: 1.05 + 0.05 * t, ty: 0.045 - 0.09 * t };
    case "Crane Down":
      return { ...z, scale: 1.05 + 0.05 * t, ty: -0.045 + 0.09 * t };
    case "Vertigo Dolly":
      return { ...z, scale: 1.0 + 0.20 * t, rotate: 0.8 * Math.sin(t * Math.PI) };
    case "Orbit":
      return {
        ...z,
        scale: 1.06,
        tx: 0.022 * Math.sin(t * Math.PI * 2),
        ty: 0.014 * Math.cos(t * Math.PI * 2),
        rotate: 1.4 * Math.sin(t * Math.PI * 2),
      };
    case "Parallax Drift":
      return { ...z, scale: 1.05, tx: -0.03 + 0.06 * t, ty: 0.015 - 0.03 * t };
    case "Whip Pan Right": {
      const e = t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
      const dist = Math.abs(t - 0.5);
      return { ...z, scale: 1.06, tx: -0.06 + 0.12 * e, blur: Math.max(0, 12 - dist * 48) };
    }
    case "Rack Focus":
      return { ...z, scale: 1.05, blur: Math.max(0, 10 * (1 - Math.min(1, t * 2.2))) };
    case "Earthquake Shake":
      return {
        ...z,
        scale: 1.08,
        tx: 0.008 * Math.sin(t * Math.PI * 30),
        ty: 0.008 * Math.cos(t * Math.PI * 28),
        rotate: 0.5 * Math.sin(t * Math.PI * 26),
      };
    case "Handheld Documentary":
      return {
        ...z,
        scale: 1.05 + 0.02 * Math.sin(t * Math.PI * 4),
        tx: Math.sin(t * Math.PI * 6) * 0.005,
        ty: Math.cos(t * Math.PI * 5) * 0.005,
        rotate: 0.25 * Math.sin(t * Math.PI * 3),
      };
    case "Static":
    default:
      return z;
  }
}

/** Build a CSS transform string from a camera frame, sized to the container. */
export function cameraToCss(frame: CameraFrame): { transform: string; filter: string } {
  const transform = `translate(${frame.tx * 100}%, ${frame.ty * 100}%) scale(${frame.scale}) rotate(${frame.rotate}deg)`;
  const filter = frame.blur > 0 ? `blur(${frame.blur}px)` : "none";
  return { transform, filter };
}