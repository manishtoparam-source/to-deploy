import type { AspectRatio, CameraMovement, TemplateSlug } from "./templates";
import type { ExportResolution, TitleMotionEffect } from "./templates";

export interface ProjectState {
  chapter_label: string;
  main_title: string;
  subtitle: string;
  selected_style: TemplateSlug;
  duration: number;
  aspect_ratio: AspectRatio;
  highlight_color: string;
  film_grain_enabled: boolean;
  camera_movement: CameraMovement;
  text_size: number;
  background_intensity: number;
  project_name: string;
  brand_kit_id: string | null;
  export_resolution: ExportResolution;
  custom_background_url: string | null;
  title_motion: TitleMotionEffect;
}

export const DEFAULT_PROJECT: ProjectState = {
  chapter_label: "CHAPTER 03",
  main_title: "THE COLLAPSE",
  subtitle: "",
  selected_style: "documentary-dark",
  duration: 5,
  aspect_ratio: "16:9",
  highlight_color: "#b6ff3b",
  film_grain_enabled: true,
  camera_movement: "Slow Push In",
  text_size: 80,
  background_intensity: 70,
  project_name: "Untitled Project",
  brand_kit_id: null,
  export_resolution: "1080p",
  custom_background_url: null,
  title_motion: "None",
};