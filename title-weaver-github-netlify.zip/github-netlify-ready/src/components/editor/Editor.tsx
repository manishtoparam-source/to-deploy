import { useEffect, useMemo, useRef, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useNavigate, Link } from "@tanstack/react-router";
import { ArrowLeft, Film, Play, Pause, Save, Download, Loader2, Image as ImageIcon, Copy, Trash2, ExternalLink, Upload, X } from "lucide-react";
import { toast } from "sonner";

import { getProject, updateProject, createRenderJob, completeRenderJob, failRenderJob, deleteProject } from "@/lib/projects.functions";
import { listBrandKits } from "@/lib/brand-kits.functions";
import { supabase } from "@/integrations/supabase/client";
import { Logo } from "@/components/branding/Logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

import { TitleCard, type BrandKitShape } from "@/components/title-card/TitleCard";
import { TEMPLATES, ASPECT_RATIOS, CAMERA_MOVEMENTS, DURATIONS, EXPORT_RESOLUTIONS, aspectStyle, aspectToWH, exportDimensions, type AspectRatio, type CameraMovement, type ExportResolution, type TemplateSlug } from "@/lib/templates";
import { TITLE_MOTIONS, type TitleMotionEffect } from "@/lib/templates";
import type { ProjectState } from "@/lib/project-state";
import { renderTitleCardToWebM } from "@/lib/render-video";

export function Editor({ projectId }: { projectId: string }) {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const get = useServerFn(getProject);
  const update = useServerFn(updateProject);
  const createJob = useServerFn(createRenderJob);
  const completeJob = useServerFn(completeRenderJob);
  const failJob = useServerFn(failRenderJob);
  const del = useServerFn(deleteProject);
  const fetchKits = useServerFn(listBrandKits);

  const { data: project, isLoading } = useQuery({
    queryKey: ["project", projectId],
    queryFn: () => get({ data: { id: projectId } }),
  });

  const { data: brandKits } = useQuery({
    queryKey: ["brand-kits"],
    queryFn: () => fetchKits(),
  });

  const [state, setState] = useState<ProjectState | null>(null);
  const [playToken, setPlayToken] = useState(0); // remount preview to replay
  const [renderState, setRenderState] = useState<
    | { kind: "idle" }
    | { kind: "rendering"; progress: number }
    | { kind: "done"; videoUrl: string; imageUrl: string }
    | { kind: "error"; message: string }
  >({ kind: "idle" });

  useEffect(() => {
    if (project && !state) {
      setState({
        chapter_label: project.chapter_label,
        main_title: project.main_title,
        subtitle: project.subtitle ?? "",
        selected_style: project.selected_style as TemplateSlug,
        duration: project.duration,
        aspect_ratio: project.aspect_ratio as AspectRatio,
        highlight_color: project.highlight_color,
        film_grain_enabled: project.film_grain_enabled,
        camera_movement: project.camera_movement as CameraMovement,
        text_size: project.text_size,
        background_intensity: project.background_intensity,
        project_name: project.project_name,
        brand_kit_id: (project as any).brand_kit_id ?? null,
        export_resolution: ((project as any).export_resolution as ExportResolution) ?? "1080p",
        custom_background_url: (project as any).custom_background_url ?? null,
        title_motion: ((project as any).title_motion as TitleMotionEffect) ?? "None",
      });
    }
  }, [project, state]);

  const activeBrandKit: BrandKitShape | null = useMemo(() => {
    if (!state?.brand_kit_id || !brandKits) return null;
    return (brandKits as any[]).find((k) => k.id === state.brand_kit_id) ?? null;
  }, [state?.brand_kit_id, brandKits]);

  const saveMut = useMutation({
    mutationFn: (patch: Partial<ProjectState>) => update({ data: { id: projectId, patch: patch as any } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["projects"] }),
  });

  const previewRef = useRef<HTMLDivElement>(null);
  const captureRef = useRef<HTMLDivElement>(null);
  const bgFileRef = useRef<HTMLInputElement>(null);
  const [uploadingBg, setUploadingBg] = useState(false);

  function patch<K extends keyof ProjectState>(k: K, v: ProjectState[K]) {
    setState((s) => (s ? { ...s, [k]: v } : s));
  }

  async function handleUploadBackground(file: File) {
    if (!file.type.startsWith("image/")) { toast.error("Please choose an image file"); return; }
    if (file.size > 15 * 1024 * 1024) { toast.error("Image must be under 15 MB"); return; }
    setUploadingBg(true);
    try {
      const { data: u } = await supabase.auth.getUser();
      const userId = u.user!.id;
      const ext = file.name.split(".").pop()?.toLowerCase() || "jpg";
      const path = `${userId}/${projectId}/${Date.now()}.${ext}`;
      const up = await supabase.storage.from("project-backgrounds").upload(path, file, { upsert: true, contentType: file.type });
      if (up.error) throw up.error;
      const signed = await supabase.storage.from("project-backgrounds").createSignedUrl(path, 60 * 60 * 24 * 365 * 10);
      if (signed.error) throw signed.error;
      patch("custom_background_url", signed.data.signedUrl);
      await saveMut.mutateAsync({ custom_background_url: signed.data.signedUrl });
      toast.success("Background uploaded");
    } catch (e: any) {
      toast.error("Upload failed: " + (e?.message ?? String(e)));
    } finally {
      setUploadingBg(false);
    }
  }

  async function handleClearBackground() {
    patch("custom_background_url", null);
    await saveMut.mutateAsync({ custom_background_url: null });
    toast.success("Reverted to template background");
  }

  async function handleSave() {
    if (!state) return;
    await saveMut.mutateAsync(state);
    toast.success("Saved");
  }

  async function handleRender() {
    if (!state || !captureRef.current) return;
    setRenderState({ kind: "rendering", progress: 0 });
    let jobId: string | null = null;
    try {
      await saveMut.mutateAsync(state);
      const job = await createJob({ data: { project_id: projectId } });
      jobId = job.id;

      const { w: W, h: H } = exportDimensions(state.aspect_ratio, state.export_resolution);

      const { webmBlob, pngBlob } = await renderTitleCardToWebM({
        node: captureRef.current,
        width: W, height: H,
        durationSec: state.duration,
        camera: state.camera_movement,
        onProgress: (p) => setRenderState({ kind: "rendering", progress: p }),
      });

      const { data: u } = await supabase.auth.getUser();
      const userId = u.user!.id;
      const stamp = Date.now();
      const videoPath = `${userId}/${projectId}/${stamp}.webm`;
      const posterPath = `${userId}/${projectId}/${stamp}.png`;

      const up1 = await supabase.storage.from("renders").upload(videoPath, webmBlob, { contentType: "video/webm", upsert: true });
      if (up1.error) throw up1.error;
      const up2 = await supabase.storage.from("renders").upload(posterPath, pngBlob, { contentType: "image/png", upsert: true });
      if (up2.error) throw up2.error;

      const sV = await supabase.storage.from("renders").createSignedUrl(videoPath, 60 * 60 * 24 * 7);
      const sP = await supabase.storage.from("renders").createSignedUrl(posterPath, 60 * 60 * 24 * 7);
      const videoUrl = sV.data!.signedUrl;
      const imageUrl = sP.data!.signedUrl;

      await completeJob({ data: { job_id: job.id, project_id: projectId, video_url: videoUrl, preview_image_url: imageUrl } });
      setRenderState({ kind: "done", videoUrl, imageUrl });
      qc.invalidateQueries({ queryKey: ["project", projectId] });
      qc.invalidateQueries({ queryKey: ["projects"] });
    } catch (err: any) {
      console.error(err);
      if (jobId) await failJob({ data: { job_id: jobId, message: String(err?.message ?? err) } }).catch(() => {});
      setRenderState({ kind: "error", message: String(err?.message ?? err) });
      toast.error("Render failed: " + String(err?.message ?? err));
    }
  }

  function copyPrompt() {
    if (!state) return;
    const { project_name: _n, ...rest } = state;
    navigator.clipboard.writeText(JSON.stringify(rest, null, 2));
    toast.success("Prompt JSON copied");
  }

  async function downloadFromUrl(url: string, filename: string) {
    const res = await fetch(url);
    const blob = await res.blob();
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = filename;
    document.body.appendChild(a); a.click(); a.remove();
  }

  if (isLoading || !state) {
    return <div className="min-h-screen grid place-items-center text-muted-foreground"><Loader2 className="animate-spin" /></div>;
  }

  return (
    <div className="min-h-screen flex flex-col">
      {/* Top header */}
      <header className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4 px-4 lg:px-6 py-3 border-b border-border bg-surface/60 backdrop-blur">
        <div className="flex min-w-0 items-center gap-4">
          <button onClick={() => navigate({ to: "/dashboard" })} className="shrink-0 size-9 grid place-items-center rounded-md hover:bg-surface-2" title="Back">
            <ArrowLeft className="size-4" />
          </button>
          <Logo />
          <Input
            value={state.project_name}
            onChange={(e) => patch("project_name", e.target.value)}
            onBlur={handleSave}
            className="hidden md:block max-w-xs bg-surface border-border h-9"
          />
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <Select value={state.export_resolution} onValueChange={(v) => patch("export_resolution", v as ExportResolution)}>
            <SelectTrigger className="w-[100px] bg-surface border-border h-9" title="Export resolution"><SelectValue /></SelectTrigger>
            <SelectContent>{EXPORT_RESOLUTIONS.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}</SelectContent>
          </Select>
          <Select value={state.aspect_ratio} onValueChange={(v) => patch("aspect_ratio", v as AspectRatio)}>
            <SelectTrigger className="w-[110px] bg-surface border-border h-9"><SelectValue /></SelectTrigger>
            <SelectContent>{ASPECT_RATIOS.map((a) => <SelectItem key={a} value={a}>{a}</SelectItem>)}</SelectContent>
          </Select>
          <Button onClick={handleSave} variant="outline" size="sm" className="border-border bg-surface h-9 hidden sm:inline-flex">
            <Save className="size-4 mr-1.5" /> Save
          </Button>
          <Button onClick={handleRender} disabled={renderState.kind === "rendering"} className="h-9 bg-neon text-neon-foreground hover:bg-neon/90 font-semibold">
            {renderState.kind === "rendering" ? (
              <><Loader2 className="size-4 mr-1.5 animate-spin" /> Rendering…</>
            ) : (
              <><Film className="size-4 mr-1.5" /> Render Video</>
            )}
          </Button>
        </div>
      </header>

      <div className="flex-1 grid lg:grid-cols-[340px_minmax(0,1fr)] min-h-0">
        {/* Left sidebar */}
        <aside className="border-r border-border bg-surface/40 p-4 lg:p-5 overflow-y-auto space-y-6 order-2 lg:order-1">
          <StepHeading n={1} title="Enter chapter title" />
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label className="text-xs uppercase tracking-widest text-muted-foreground">Chapter label</Label>
              <Input value={state.chapter_label} onChange={(e) => patch("chapter_label", e.target.value)} maxLength={40} className="bg-background border-border" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs uppercase tracking-widest text-muted-foreground">Main title</Label>
              <Textarea value={state.main_title} onChange={(e) => patch("main_title", e.target.value)} maxLength={80} rows={2} className="bg-background border-border resize-none" />
              <div className="text-right text-[10px] text-muted-foreground font-mono">{state.main_title.length}/80</div>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs uppercase tracking-widest text-muted-foreground">Subtitle (optional)</Label>
              <Input value={state.subtitle} onChange={(e) => patch("subtitle", e.target.value)} maxLength={80} className="bg-background border-border" />
            </div>
          </div>

          <StepHeading n={2} title="Choose style" />
          <Select value={state.selected_style} onValueChange={(v) => patch("selected_style", v as TemplateSlug)}>
            <SelectTrigger className="bg-background border-border h-12"><SelectValue /></SelectTrigger>
            <SelectContent>
              {TEMPLATES.map((t) => (
                <SelectItem key={t.slug} value={t.slug}>
                  <div className="flex items-center gap-2"><span className="size-2 rounded-full" style={{ backgroundColor: t.accent }} /> {t.name}</div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <StepHeading n={3} title="Settings" />
          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label className="text-xs uppercase tracking-widest text-muted-foreground">Duration</Label>
              <Select value={String(state.duration)} onValueChange={(v) => patch("duration", parseInt(v))}>
                <SelectTrigger className="bg-background border-border"><SelectValue /></SelectTrigger>
                <SelectContent>{DURATIONS.map((d) => <SelectItem key={d} value={String(d)}>{d} seconds</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs uppercase tracking-widest text-muted-foreground">Highlight color</Label>
              <div className="flex items-center gap-2">
                <input type="color" value={state.highlight_color} onChange={(e) => patch("highlight_color", e.target.value)} className="size-9 rounded-md border border-border bg-transparent cursor-pointer" />
                <Input value={state.highlight_color} onChange={(e) => patch("highlight_color", e.target.value)} className="bg-background border-border font-mono" />
              </div>
            </div>
            <div className="flex items-center justify-between rounded-lg border border-border bg-background px-3 py-2.5">
              <div>
                <div className="text-sm">Film grain</div>
                <div className="text-xs text-muted-foreground">Cinematic texture overlay</div>
              </div>
              <Switch checked={state.film_grain_enabled} onCheckedChange={(v) => patch("film_grain_enabled", v)} />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs uppercase tracking-widest text-muted-foreground">Camera movement</Label>
              <Select value={state.camera_movement} onValueChange={(v) => patch("camera_movement", v as CameraMovement)}>
                <SelectTrigger className="bg-background border-border"><SelectValue /></SelectTrigger>
                <SelectContent>{CAMERA_MOVEMENTS.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5">
              <Label className="text-xs uppercase tracking-widest text-muted-foreground">Title movement effects</Label>
              <Select value={state.title_motion} onValueChange={(v) => patch("title_motion", v as TitleMotionEffect)}>
                <SelectTrigger className="bg-background border-border"><SelectValue /></SelectTrigger>
                <SelectContent>{TITLE_MOTIONS.map((m) => <SelectItem key={m} value={m}>{m}</SelectItem>)}</SelectContent>
              </Select>
              <div className="text-[10px] text-muted-foreground">Animates the chapter label, title, and subtitle.</div>
            </div>

            <div className="space-y-1.5">
              <Label className="text-xs uppercase tracking-widest text-muted-foreground">Custom background</Label>
              <input
                ref={bgFileRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => { const f = e.target.files?.[0]; if (f) handleUploadBackground(f); e.target.value = ""; }}
              />
              {state.custom_background_url ? (
                <div className="rounded-lg border border-border bg-background overflow-hidden">
                  <img src={state.custom_background_url} alt="" className="w-full h-20 object-cover" />
                  <div className="flex gap-1 p-1.5">
                    <Button onClick={() => bgFileRef.current?.click()} disabled={uploadingBg} variant="outline" size="sm" className="flex-1 h-8 border-border bg-surface text-xs">
                      {uploadingBg ? <Loader2 className="size-3 animate-spin" /> : <><Upload className="size-3 mr-1" /> Replace</>}
                    </Button>
                    <Button onClick={handleClearBackground} variant="ghost" size="sm" className="h-8 text-destructive hover:text-destructive">
                      <X className="size-3" />
                    </Button>
                  </div>
                </div>
              ) : (
                <Button onClick={() => bgFileRef.current?.click()} disabled={uploadingBg} variant="outline" className="w-full h-10 border-dashed border-border bg-background">
                  {uploadingBg ? <><Loader2 className="size-4 mr-1.5 animate-spin" /> Uploading…</> : <><Upload className="size-4 mr-1.5" /> Upload image</>}
                </Button>
              )}
              <div className="text-[10px] text-muted-foreground">Overrides the template's background. JPG/PNG up to 15 MB.</div>
            </div>

            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <Label className="text-xs uppercase tracking-widest text-muted-foreground">Brand kit</Label>
                <Link to="/brand-kits" className="text-[10px] uppercase tracking-widest text-neon hover:underline inline-flex items-center gap-1">
                  Manage <ExternalLink className="size-3" />
                </Link>
              </div>
              <Select
                value={state.brand_kit_id ?? "__none"}
                onValueChange={(v) => patch("brand_kit_id", v === "__none" ? null : v)}
              >
                <SelectTrigger className="bg-background border-border">
                  <SelectValue placeholder="None" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="__none">No brand kit</SelectItem>
                  {(brandKits as any[] | undefined)?.map((k) => (
                    <SelectItem key={k.id} value={k.id}>
                      <span className="inline-flex items-center gap-2">
                        <span className="size-2 rounded-full" style={{ backgroundColor: k.primary_color }} />
                        {k.name}
                      </span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {activeBrandKit && (
                <div className="text-[10px] text-muted-foreground font-mono">
                  Heading: {activeBrandKit.heading_font_family_name || activeBrandKit.heading_font} · Body: {activeBrandKit.body_font_family_name || activeBrandKit.body_font}
                </div>
              )}
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-xs uppercase tracking-widest text-muted-foreground">Background intensity</Label>
                <span className="text-xs font-mono text-muted-foreground">{state.background_intensity}</span>
              </div>
              <Slider value={[state.background_intensity]} onValueChange={([v]) => patch("background_intensity", v)} min={0} max={100} step={1} />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-xs uppercase tracking-widest text-muted-foreground">Text size</Label>
                <span className="text-xs font-mono text-muted-foreground">{state.text_size}</span>
              </div>
              <Slider value={[state.text_size]} onValueChange={([v]) => patch("text_size", v)} min={40} max={140} step={1} />
            </div>
          </div>

          <div className="pt-4 border-t border-border space-y-2">
            <Button onClick={handleSave} variant="outline" className="w-full border-border bg-surface">
              <Save className="size-4 mr-1.5" /> Save project
            </Button>
            <Button onClick={async () => { if (confirm("Delete project?")) { await del({ data: { id: projectId } }); navigate({ to: "/dashboard" }); } }}
              variant="ghost" className="w-full text-destructive hover:text-destructive">
              <Trash2 className="size-4 mr-1.5" /> Delete project
            </Button>
          </div>
        </aside>

        {/* Center preview + gallery */}
        <section className="flex flex-col min-h-0 order-1 lg:order-2">
          <div className="flex-1 grid place-items-center p-4 lg:p-8 min-h-0">
            <div className="w-full max-w-5xl">
              <div className="flex items-center justify-between mb-3">
                <div className="font-mono text-xs uppercase tracking-[0.4em] text-muted-foreground">Preview</div>
                <div className="font-mono text-xs text-muted-foreground">{state.aspect_ratio} · {state.duration}s</div>
              </div>
              <div
                ref={previewRef}
                className="relative w-full rounded-2xl overflow-hidden border border-border shadow-neon bg-black"
                style={{ aspectRatio: aspectStyle(state.aspect_ratio) }}
              >
                <div key={playToken} className="absolute inset-0">
                  <TitleCard data={state} playing brandKit={activeBrandKit} />
                </div>
                {/* hidden capture surface (no animation) for static render base */}
                <div ref={captureRef} className="absolute -left-[10000px] top-0" style={{ width: aspectToWH(state.aspect_ratio).w / 2, height: aspectToWH(state.aspect_ratio).h / 2 }}>
                  <div className="relative w-full h-full">
                    <TitleCard data={state} progress={0.55} brandKit={activeBrandKit} />
                  </div>
                </div>
              </div>
              <PlayerBar
                duration={state.duration}
                onReplay={() => setPlayToken((t) => t + 1)}
              />
            </div>
          </div>

          <div className="border-t border-border bg-surface/40 p-4 lg:p-5">
            <div className="font-mono text-[10px] uppercase tracking-[0.4em] text-muted-foreground mb-3">Choose template style</div>
            <div className="flex gap-3 overflow-x-auto pb-2 -mx-1 px-1">
              {TEMPLATES.map((t) => {
                const active = state.selected_style === t.slug;
                return (
                  <button
                    key={t.slug}
                    onClick={() => patch("selected_style", t.slug)}
                    className={`shrink-0 w-44 rounded-xl border overflow-hidden text-left transition-all ${active ? "border-neon shadow-neon" : "border-border hover:border-muted-foreground"}`}
                  >
                    <div className="aspect-video relative bg-black">
                      <TitleCard data={{ ...state, selected_style: t.slug, film_grain_enabled: false, custom_background_url: null }} progress={0.5} brandKit={activeBrandKit} />
                      {active && <div className="absolute top-1.5 right-1.5 size-5 rounded-full bg-neon grid place-items-center text-[10px] font-bold text-neon-foreground">✓</div>}
                    </div>
                    <div className="px-2.5 py-2 text-xs flex items-center justify-between bg-surface">
                      <span className="truncate">{t.name}</span>
                      <span className="size-2 rounded-full shrink-0" style={{ backgroundColor: t.accent }} />
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* feature strip */}
          <div className="border-t border-border bg-surface/20 px-4 py-3 grid grid-cols-2 md:grid-cols-4 gap-3 text-[11px] text-muted-foreground">
            {["Professional chapter animations", "Boost your video retention", "Perfect for YouTube videos", "Export in high quality"].map((t) => (
              <div key={t} className="flex items-center gap-2 min-w-0"><span className="size-1.5 rounded-full bg-neon shrink-0" /><span className="truncate">{t}</span></div>
            ))}
          </div>
        </section>
      </div>

      <Dialog open={renderState.kind !== "idle"} onOpenChange={(o) => { if (!o) setRenderState({ kind: "idle" }); }}>
        <DialogContent className="bg-surface border-border">
          {renderState.kind === "rendering" && (
            <>
              <DialogHeader><DialogTitle>Rendering your chapter title video…</DialogTitle></DialogHeader>
              <div className="py-4 space-y-3">
                <div className="h-2 rounded-full bg-surface-2 overflow-hidden"><div className="h-full bg-neon transition-all" style={{ width: `${Math.round(renderState.progress * 100)}%` }} /></div>
                <div className="text-xs text-muted-foreground font-mono text-center">{Math.round(renderState.progress * 100)}%</div>
              </div>
            </>
          )}
          {renderState.kind === "done" && (
            <>
              <DialogHeader><DialogTitle>Render complete</DialogTitle></DialogHeader>
              <video src={renderState.videoUrl} controls autoPlay loop className="w-full rounded-lg border border-border" />
              <div className="grid grid-cols-2 gap-2 mt-4">
                    <Button onClick={() => downloadFromUrl(renderState.videoUrl, `${state.project_name}-${state.export_resolution}.webm`)} className="bg-neon text-neon-foreground hover:bg-neon/90"><Download className="size-4 mr-1.5" /> Download {state.export_resolution}</Button>
                <Button onClick={() => downloadFromUrl(renderState.imageUrl, `${state.project_name}.png`)} variant="outline" className="border-border bg-background"><ImageIcon className="size-4 mr-1.5" /> Download PNG</Button>
                <Button onClick={copyPrompt} variant="outline" className="border-border bg-background"><Copy className="size-4 mr-1.5" /> Copy prompt</Button>
                <Button onClick={() => setRenderState({ kind: "idle" })} variant="ghost">Edit again</Button>
              </div>
            </>
          )}
          {renderState.kind === "error" && (
            <>
              <DialogHeader><DialogTitle>Render failed</DialogTitle></DialogHeader>
              <p className="text-sm text-muted-foreground">{renderState.message}</p>
              <Button onClick={handleRender} className="bg-neon text-neon-foreground hover:bg-neon/90 mt-3">Try again</Button>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function StepHeading({ n, title }: { n: number; title: string }) {
  return (
    <div className="flex items-center gap-2">
      <div className="size-5 rounded-full bg-neon text-neon-foreground grid place-items-center text-[10px] font-bold">{n}</div>
      <div className="font-semibold text-sm">{title}</div>
    </div>
  );
}

function PlayerBar({ duration, onReplay }: { duration: number; onReplay: () => void }) {
  const [t, setT] = useState(0);
  const [playing, setPlaying] = useState(true);
  useEffect(() => {
    if (!playing) return;
    const start = performance.now() - t * 1000;
    let raf = 0;
    const tick = () => {
      const elapsed = (performance.now() - start) / 1000;
      if (elapsed >= duration) { setT(duration); setPlaying(false); return; }
      setT(elapsed);
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [playing, duration]);

  return (
    <div className="mt-3 flex items-center gap-3 px-3 py-2 rounded-xl border border-border bg-surface">
      <button onClick={() => { if (t >= duration) { setT(0); onReplay(); } setPlaying((p) => !p); }} className="size-8 grid place-items-center rounded-full bg-neon text-neon-foreground">
        {playing ? <Pause className="size-4" /> : <Play className="size-4" />}
      </button>
      <div className="flex-1 h-1.5 rounded-full bg-surface-2 overflow-hidden">
        <div className="h-full bg-neon" style={{ width: `${Math.min(100, (t / duration) * 100)}%` }} />
      </div>
      <div className="font-mono text-[11px] text-muted-foreground tabular-nums">{t.toFixed(1)} / {duration.toFixed(1)}</div>
      <div className="text-[10px] font-mono px-1.5 py-0.5 rounded border border-border text-muted-foreground">HD</div>
    </div>
  );
}