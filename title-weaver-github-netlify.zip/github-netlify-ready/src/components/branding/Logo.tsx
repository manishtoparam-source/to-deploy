import { Link } from "@tanstack/react-router";

export function Logo({ small = false }: { small?: boolean }) {
  return (
    <Link to="/" className="flex items-center gap-3 group">
      <div
        className={`relative ${small ? "size-7" : "size-9"} rounded-lg bg-surface-2 border border-border grid place-items-center overflow-hidden`}
      >
        <div className="absolute inset-0 bg-gradient-to-br from-neon/20 to-transparent" />
        <span className="relative font-display text-neon text-base leading-none">C</span>
        <span className="absolute bottom-0.5 right-1 font-mono text-[0.5rem] text-neon/80">/T</span>
      </div>
      {!small && (
        <div className="flex flex-col leading-none">
          <span className="font-semibold tracking-tight">Chapter Title Generator</span>
          <span className="text-[0.65rem] uppercase tracking-[0.3em] text-muted-foreground mt-1">
            cinematic title cards
          </span>
        </div>
      )}
    </Link>
  );
}