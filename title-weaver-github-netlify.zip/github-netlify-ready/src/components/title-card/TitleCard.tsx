import { useEffect, useRef, useState } from "react";
import type { CSSProperties, ReactNode } from "react";
import type { ProjectState } from "@/lib/project-state";
import { cameraAt, cameraToCss } from "@/lib/camera";
import { loadCustomFont, loadGoogleFont } from "@/lib/google-fonts";
import { TEMPLATES, type TemplateMeta } from "@/lib/templates";
import type { TitleMotionEffect } from "@/lib/templates";

export interface BrandKitShape {
  id: string;
  primary_color: string;
  background_color: string;
  text_color: string;
  heading_font: string;
  body_font: string;
  heading_font_url: string | null;
  body_font_url: string | null;
  heading_font_family_name: string | null;
  body_font_family_name: string | null;
  logo_url: string | null;
  logo_position: string;
  logo_size: number;
  logo_opacity: number;
}

interface Props {
  data: ProjectState;
  playing?: boolean;
  /** progress 0..1; if provided, drives the animation manually */
  progress?: number;
  brandKit?: BrandKitShape | null;
}

function useLoopingProgress(durationSec: number, enabled: boolean): number {
  const [p, setP] = useState(0);
  useEffect(() => {
    if (!enabled) {
      setP(0);
      return;
    }
    let raf = 0;
    const start = performance.now();
    const tick = (now: number) => {
      const t = (now - start) / 1000 / Math.max(0.5, durationSec);
      setP(Math.min(1, t));
      if (t < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [durationSec, enabled]);
  return p;
}

function resolveBrandFonts(kit: BrandKitShape | null | undefined) {
  const heading = kit?.heading_font_url
    ? (kit.heading_font_family_name || "BrandHeading")
    : kit?.heading_font ?? null;
  const body = kit?.body_font_url
    ? (kit.body_font_family_name || "BrandBody")
    : kit?.body_font ?? null;
  return { heading, body };
}

export function TitleCard({ data, playing = true, progress, brandKit }: Props) {
  const { camera_movement, film_grain_enabled, duration, selected_style, custom_background_url } = data;

  const template: TemplateMeta = TEMPLATES.find((t) => t.slug === selected_style) ?? TEMPLATES[0];
  const backgroundUrl = custom_background_url || template.background;
  const isLight = !!template.light && !custom_background_url;

  // Make sure brand-kit fonts are loaded (Google or custom).
  useEffect(() => {
    if (!brandKit) return;
    if (brandKit.heading_font_url) {
      loadCustomFont(brandKit.heading_font_family_name || "BrandHeading", brandKit.heading_font_url);
    } else if (brandKit.heading_font) {
      loadGoogleFont(brandKit.heading_font);
    }
    if (brandKit.body_font_url) {
      loadCustomFont(brandKit.body_font_family_name || "BrandBody", brandKit.body_font_url);
    } else if (brandKit.body_font) {
      loadGoogleFont(brandKit.body_font);
    }
  }, [brandKit]);

  const loopP = useLoopingProgress(duration, playing && progress === undefined);
  const t = progress !== undefined ? progress : loopP;
  const frame = cameraAt(camera_movement, t);
  const css = cameraToCss(frame);

  const fonts = resolveBrandFonts(brandKit);
  const wrapperStyle: CSSProperties = {
    transform: css.transform,
    filter: css.filter,
    transformOrigin: "center center",
    willChange: "transform, filter",
  };
  const brandStyle: CSSProperties = brandKit
    ? ({
        // CSS vars consumed by [data-brand-kit] rules in styles.css
        ["--brand-heading" as any]: fonts.heading ? `"${fonts.heading}"` : undefined,
        ["--brand-body" as any]: fonts.body ? `"${fonts.body}"` : undefined,
      } as CSSProperties)
    : {};

  return (
    <div
      className="absolute inset-0 overflow-hidden bg-black"
      data-brand-kit={brandKit ? "" : undefined}
      style={brandStyle}
    >
      {/* Background plate — scales/pans with camera movement */}
      <div className="absolute inset-0" style={wrapperStyle}>
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: `url(${backgroundUrl})`,
            opacity: Math.max(0.25, data.background_intensity / 100),
          }}
        />
      </div>
      {/* Style-specific tints/overlays + text */}
      <StyleLayer data={data} brandKit={brandKit} isLight={isLight} progress={t} />
      {brandKit?.logo_url && <LogoOverlay kit={brandKit} />}
      {film_grain_enabled && <div className="absolute inset-0 film-grain opacity-70" />}
    </div>
  );
}

function LogoOverlay({ kit }: { kit: BrandKitShape }) {
  const pos: CSSProperties = {};
  const pad = "4%";
  if (kit.logo_position.startsWith("top")) pos.top = pad;
  else pos.bottom = pad;
  if (kit.logo_position.endsWith("left")) pos.left = pad;
  else pos.right = pad;
  return (
    <img
      src={kit.logo_url!}
      alt=""
      crossOrigin="anonymous"
      style={{
        position: "absolute",
        ...pos,
        width: `${kit.logo_size}%`,
        opacity: kit.logo_opacity / 100,
        pointerEvents: "none",
        objectFit: "contain",
      }}
    />
  );
}

function StyleLayer({ data, brandKit, isLight, progress }: { data: ProjectState; brandKit?: BrandKitShape | null; isLight: boolean; progress: number }) {
  const { selected_style } = data;
  // Brand-kit primary color overrides the highlight when a kit is selected.
  const effective: ProjectState = brandKit
    ? { ...data, highlight_color: brandKit.primary_color }
    : data;
  // If a custom background is used and template was "light", we still use light styles
  // (text color choice is controlled by `isLight` from parent now).
  const _light = isLight;
  const motion: TitleMotionEffect = (effective.title_motion as TitleMotionEffect) ?? "None";
  const inner = (() => {
    switch (selected_style) {
      case "documentary-dark": return <DocumentaryDark data={effective} />;
      case "newspaper": return <Newspaper data={effective} light={_light} />;
      case "retro-vhs": return <RetroVHS data={effective} />;
      case "minimal-clean": return <MinimalClean data={effective} light={_light} />;
      case "crime-file": return <CrimeFile data={effective} />;
      case "cinematic-gold": return <CinematicGold data={effective} />;
      case "glitch-cyber": return <GlitchCyber data={effective} />;
      case "archive-film": return <ArchiveFilm data={effective} />;
      case "court-document": return <CourtDocument data={effective} light={_light} />;
      case "breaking-news": return <BreakingNews data={effective} />;
      default: return <DocumentaryDark data={effective} />;
    }
  })();
  if (motion === "None") return inner;
  // Wrap the template output with a global title-motion overlay layer that
  // targets every text element inside via CSS descendant selectors.
  return (
    <TitleMotionWrap motion={motion} progress={progress}>
      {inner}
    </TitleMotionWrap>
  );
}

/* ---------- Title Motion ---------- */

function easeOutCubic(x: number) { return 1 - Math.pow(1 - x, 3); }
function clamp01(x: number) { return Math.max(0, Math.min(1, x)); }

function TitleMotionWrap({
  motion, progress, children,
}: { motion: TitleMotionEffect; progress: number; children: ReactNode }) {
  // Effects mostly resolve in the first ~35% of the clip.
  const r = clamp01(progress / 0.35);
  const e = easeOutCubic(r);

  // Style applied to a wrapper that contains the entire template output.
  // We use descendant selectors on h1, p, and the chapter stamp to drive
  // the animation without restructuring every template.
  const cls: string[] = ["absolute inset-0 title-motion"];
  const style: Record<string, string> = {
    // CSS variables consumed by the .title-motion-* rules in styles.css
    "--tm-p": String(progress),
    "--tm-r": String(r),
    "--tm-e": String(e),
  };

  switch (motion) {
    case "Slow Push-In":
      cls.push("title-motion-push");
      break;
    case "Letter Fade-In":
      cls.push("title-motion-letterfade");
      break;
    case "Typewriter Reveal":
      cls.push("title-motion-typewriter");
      break;
    case "Stamp Reveal":
      cls.push("title-motion-stamp");
      break;
    case "Glitch Flicker":
      cls.push("title-motion-glitch");
      // Drive a per-frame jitter via CSS variable
      style["--tm-jx"] = `${Math.sin(progress * 60) * (1 - e) * 6}px`;
      style["--tm-jy"] = `${Math.cos(progress * 55) * (1 - e) * 4}px`;
      style["--tm-flick"] = String(0.55 + Math.abs(Math.sin(progress * 80)) * (1 - e) * 0.45 + e * 0.45);
      break;
    case "Light Sweep":
      cls.push("title-motion-sweep");
      style["--tm-sweep"] = `${-30 + progress * 160}%`;
      break;
    case "Newspaper Ink Reveal":
      cls.push("title-motion-ink");
      break;
    case "Dust Explosion Reveal":
      cls.push("title-motion-dust");
      break;
    case "Camera Pan Across Text":
      cls.push("title-motion-pan");
      break;
    case "Word Scale Pop":
      cls.push("title-motion-pop");
      break;
  }

  return (
    <div className={cls.join(" ")} style={style as CSSProperties}>
      {children}
    </div>
  );
}

function sizePct(textSize: number, base: number) {
  return (base * textSize) / 80;
}

/* Chapter stamp matching the cinematic reference:
   thin double-line outline, side dashes flanking the text. */
function ChapterStamp({ children, color }: { children: ReactNode; color: string }) {
  return (
    <div className="relative inline-flex items-center gap-[1.5cqw]" style={{ color }}>
      <span className="block h-px w-[5cqw]" style={{ backgroundColor: color, opacity: 0.7 }} />
      <span
        className="font-mono uppercase tracking-[0.45em] px-[1.8cqw] py-[0.7cqw] text-[1.05cqw]"
        style={{
          border: `1.5px solid ${color}`,
          boxShadow: `inset 0 0 0 3px rgba(0,0,0,0.0), 0 0 0 4px transparent`,
          background: "rgba(0,0,0,0.18)",
        }}
      >
        {children}
      </span>
      <span className="block h-px w-[5cqw]" style={{ backgroundColor: color, opacity: 0.7 }} />
    </div>
  );
}

/* Reusable cinematic overlays */
function Vignette() {
  return <div className="absolute inset-0 cine-vignette" />;
}
function LightSpot() {
  return <div className="absolute inset-0 cine-spot" />;
}
function Dust() {
  return <div className="absolute inset-0 cine-dust" />;
}

/* Small ornamental cross divider seen under the title in the reference. */
function CrossDivider({ color = "rgba(255,255,255,0.55)" }: { color?: string }) {
  return (
    <div className="flex items-center gap-[1cqw]" style={{ color }}>
      <span className="block h-px w-[8cqw]" style={{ backgroundColor: color }} />
      <span className="font-mono text-[1.4cqw] leading-none">+</span>
      <span className="block h-px w-[8cqw]" style={{ backgroundColor: color }} />
    </div>
  );
}

/* ---------- Templates ---------- */

/**
 * Every template renders on top of a photographic background plate (provided by
 * the parent). They contribute: a subtle tint/scrim for legibility plus a
 * unique typographic treatment.
 */

function Scrim({ color = "rgba(0,0,0,0.55)" }: { color?: string }) {
  return (
    <div
      className="absolute inset-0"
      style={{
        background: `radial-gradient(ellipse at center, ${color} 0%, rgba(0,0,0,0.85) 100%)`,
      }}
    />
  );
}

function DocumentaryDark({ data }: { data: ProjectState }) {
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center" style={{ containerType: "size" }}>
      <Vignette />
      <LightSpot />
      <div className="relative z-10 flex flex-col items-center gap-[2.4cqw] text-center px-[8cqw]">
        <ChapterStamp color={data.highlight_color}>{data.chapter_label}</ChapterStamp>
        <h1
          className="font-display text-white leading-[0.88] text-paperfill"
          style={{ fontSize: `${sizePct(data.text_size, 13)}cqw`, letterSpacing: "0.01em" }}
        >
          {data.main_title}
        </h1>
        <CrossDivider />
        {data.subtitle && (
          <p className="font-mono uppercase tracking-[0.45em] text-white/70" style={{ fontSize: `${sizePct(data.text_size, 1.2)}cqw` }}>
            {data.subtitle}
          </p>
        )}
      </div>
      <Dust />
    </div>
  );
}

function Newspaper({ data, light }: { data: ProjectState; light: boolean }) {
  const ink = light ? "#111" : "#fff";
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center" style={{ containerType: "size" }}>
      <div className="absolute inset-0" style={{ background: "linear-gradient(180deg, rgba(255,255,255,0.0) 30%, rgba(0,0,0,0.35) 100%)" }} />
      <Vignette />
      <div className="relative z-10 text-center px-[6cqw] max-w-[88%]">
        <div
          className="inline-block font-mono uppercase tracking-[0.5em] text-[0.95cqw] px-[1.5cqw] py-[0.6cqw] mb-[2cqw]"
          style={{ color: light ? "#fff" : "#111", backgroundColor: light ? "#111" : "#fff" }}
        >
          {data.chapter_label}
        </div>
        <h1
          className="font-display leading-[0.92] tracking-tight text-distressed"
          style={{
            color: ink,
            fontSize: `${sizePct(data.text_size, 14)}cqw`,
            textShadow: light ? "0 2px 0 rgba(0,0,0,0.15)" : "0 4px 30px rgba(0,0,0,0.8)",
          }}
        >
          {data.main_title}
        </h1>
        {data.subtitle && (
          <p
            className="font-mono uppercase tracking-[0.4em] mt-[1.8cqw]"
            style={{ color: light ? "#222" : "rgba(255,255,255,0.8)", fontSize: `${sizePct(data.text_size, 1.1)}cqw` }}
          >
            {data.subtitle}
          </p>
        )}
      </div>
    </div>
  );
}

function RetroVHS({ data }: { data: ProjectState }) {
  return (
    <div className="absolute inset-0 overflow-hidden" style={{ containerType: "size" }}>
      <div className="absolute inset-0 scanlines opacity-40" />
      <div className="absolute inset-0" style={{ background: "linear-gradient(45deg, rgba(255,46,166,0.12), rgba(0,255,255,0.12))" }} />
      <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-[6cqw]">
        <div className="font-mono text-[#0ff] uppercase tracking-[0.3em] text-[1.2cqw] mb-[2cqw]" style={{ textShadow: "2px 0 #ff2ea6, -2px 0 #0ff" }}>
          ▶ REC · {data.chapter_label}
        </div>
        <h1 className="font-display text-white leading-[0.9]" style={{ fontSize: `${sizePct(data.text_size, 12)}cqw`, textShadow: "3px 0 #ff2ea6, -3px 0 #00ffff" }}>
          {data.main_title}
        </h1>
        {data.subtitle && (
          <p className="font-mono text-white/80 mt-[1.5cqw] tracking-[0.3em]" style={{ fontSize: `${sizePct(data.text_size, 1.3)}cqw` }}>
            {data.subtitle}
          </p>
        )}
      </div>
      <div className="absolute top-[4cqw] right-[4cqw] font-mono text-[#ff2ea6] text-[1cqw] tracking-widest">SP · 00:00:03</div>
    </div>
  );
}

function MinimalClean({ data, light }: { data: ProjectState; light: boolean }) {
  const ink = light ? "#0a0a0a" : "#fff";
  const sub = light ? "rgba(0,0,0,0.55)" : "rgba(255,255,255,0.6)";
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center" style={{ containerType: "size" }}>
      {!light && <Vignette />}
      <div className="relative z-10 text-center px-[6cqw] flex flex-col items-center gap-[2.5cqw]">
        <div className="font-mono uppercase tracking-[0.5em]" style={{ color: sub, fontSize: "1cqw" }}>
          {data.chapter_label}
        </div>
        <div className="h-px w-[10cqw]" style={{ backgroundColor: data.highlight_color }} />
        <h1 className="font-light tracking-tight leading-[1] font-display" style={{ color: ink, fontSize: `${sizePct(data.text_size, 8)}cqw` }}>
          {data.main_title}
        </h1>
        {data.subtitle && (
          <p style={{ color: sub, fontSize: `${sizePct(data.text_size, 1.3)}cqw` }}>
            {data.subtitle}
          </p>
        )}
      </div>
    </div>
  );
}

function CrimeFile({ data }: { data: ProjectState }) {
  return (
    <div className="absolute inset-0 flex items-center justify-center" style={{ containerType: "size" }}>
      <Vignette />
      <LightSpot />
      <div className="relative z-10 flex flex-col items-center gap-[2.2cqw] text-center px-[8cqw]">
        <ChapterStamp color="#e23b3b">{data.chapter_label}</ChapterStamp>
        <h1
          className="font-display text-white leading-[0.88] text-distressed"
          style={{ fontSize: `${sizePct(data.text_size, 13)}cqw`, textShadow: "0 4px 30px rgba(0,0,0,0.85)" }}
        >
          {data.main_title}
        </h1>
        <CrossDivider color="rgba(226,59,59,0.7)" />
        {data.subtitle && (
          <p className="font-mono text-white/75 mt-[0.5cqw] uppercase tracking-[0.45em]" style={{ fontSize: `${sizePct(data.text_size, 1.1)}cqw` }}>
            {data.subtitle}
          </p>
        )}
      </div>
      <Dust />
    </div>
  );
}

function CinematicGold({ data }: { data: ProjectState }) {
  return (
    <div className="absolute inset-0 flex items-center justify-center" style={{ containerType: "size" }}>
      <Vignette />
      <LightSpot />
      <div className="relative z-10 corner-brackets text-[#e7c46a] px-[7cqw] py-[5cqw] flex flex-col items-center gap-[2cqw] text-center">
        <ChapterStamp color="#e7c46a">{data.chapter_label}</ChapterStamp>
        <h1
          className="font-display leading-[0.9] text-goldfill"
          style={{ fontSize: `${sizePct(data.text_size, 12)}cqw`, letterSpacing: "0.02em" }}
        >
          {data.main_title}
        </h1>
        <CrossDivider color="rgba(231,196,106,0.7)" />
        {data.subtitle && (
          <p className="font-mono uppercase tracking-[0.45em] text-[#e7c46a]/85" style={{ fontSize: `${sizePct(data.text_size, 1.1)}cqw` }}>
            {data.subtitle}
          </p>
        )}
      </div>
      <Dust />
    </div>
  );
}

function GlitchCyber({ data }: { data: ProjectState }) {
  return (
    <div className="absolute inset-0 overflow-hidden" style={{ containerType: "size" }}>
      <Scrim color="rgba(0,5,10,0.6)" />
      <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-[6cqw]">
        <div className="font-mono text-[#00ffd0] uppercase tracking-[0.4em] text-[1.2cqw] mb-[2cqw]">
          ::SYS/{data.chapter_label.replace(/\s+/g, "_")}
        </div>
        <h1 className="font-display text-white leading-[0.9]" style={{ fontSize: `${sizePct(data.text_size, 12)}cqw`, textShadow: "2px 0 #00ffd0, -2px 0 #ff00ff" }}>
          {data.main_title}
        </h1>
        {data.subtitle && (
          <p className="font-mono text-[#00ffd0]/80 mt-[1.5cqw]" style={{ fontSize: `${sizePct(data.text_size, 1.2)}cqw` }}>
            &gt; {data.subtitle}
          </p>
        )}
      </div>
    </div>
  );
}

/* Archive Film — sepia film plate with faded distressed white text. */
function ArchiveFilm({ data }: { data: ProjectState }) {
  return (
    <div className="absolute inset-0 flex items-center justify-center" style={{ containerType: "size" }}>
      <div className="absolute inset-0" style={{ background: "radial-gradient(ellipse at center, rgba(0,0,0,0.25) 0%, rgba(0,0,0,0.7) 100%)" }} />
      <div className="relative z-10 flex flex-col items-center gap-[2.2cqw] text-center px-[8cqw]">
        <div
          className="font-mono uppercase tracking-[0.5em] text-[1cqw] py-[0.6cqw] px-[1.5cqw]"
          style={{ color: "#f1e3c2", borderTop: "1px solid rgba(241,227,194,0.6)", borderBottom: "1px solid rgba(241,227,194,0.6)" }}
        >
          ARCHIVE · {data.chapter_label}
        </div>
        <h1
          className="font-display leading-[0.9] text-distressed"
          style={{ color: "#f3e6c8", fontSize: `${sizePct(data.text_size, 13)}cqw`, textShadow: "0 4px 24px rgba(0,0,0,0.75)" }}
        >
          {data.main_title}
        </h1>
        <CrossDivider color="rgba(241,227,194,0.55)" />
        {data.subtitle && (
          <p className="italic" style={{ color: "rgba(241,227,194,0.8)", fontSize: `${sizePct(data.text_size, 1.4)}cqw` }}>
            {data.subtitle}
          </p>
        )}
      </div>
      <Dust />
    </div>
  );
}

/* Court Document — cream legal page, black condensed title, red confidential stamp. */
function CourtDocument({ data, light }: { data: ProjectState; light: boolean }) {
  const ink = light ? "#0e0e0e" : "#fff";
  return (
    <div className="absolute inset-0 flex items-center justify-center" style={{ containerType: "size" }}>
      <div className="relative z-10 flex flex-col items-center gap-[2cqw] text-center px-[8cqw]">
        <div
          className="font-mono uppercase tracking-[0.4em] text-[1cqw] px-[1.6cqw] py-[0.6cqw]"
          style={{ color: "#b91c1c", border: "1.5px solid #b91c1c", background: "rgba(255,255,255,0.4)" }}
        >
          EXHIBIT A · {data.chapter_label}
        </div>
        <h1
          className="font-display leading-[0.9] tracking-tight"
          style={{ color: ink, fontSize: `${sizePct(data.text_size, 13)}cqw` }}
        >
          {data.main_title}
        </h1>
        <div className="h-[2px] w-[16cqw]" style={{ backgroundColor: ink, opacity: 0.6 }} />
        {data.subtitle && (
          <p className="font-mono uppercase tracking-[0.4em]" style={{ color: light ? "rgba(0,0,0,0.65)" : "rgba(255,255,255,0.75)", fontSize: `${sizePct(data.text_size, 1.1)}cqw` }}>
            {data.subtitle}
          </p>
        )}
      </div>
      {/* faux confidential stamp, rotated, in corner */}
      <div
        className="absolute top-[8cqw] right-[7cqw] font-display uppercase tracking-[0.2em] text-[2cqw] px-[1.4cqw] py-[0.4cqw] z-20 select-none"
        style={{ color: "#b91c1c", border: "3px solid #b91c1c", transform: "rotate(-14deg)", opacity: 0.85, textShadow: "0 0 0 #b91c1c" }}
      >
        CONFIDENTIAL
      </div>
    </div>
  );
}

/* Breaking News — dark newsroom, BREAKING NEWS chip, white headline, red underline. */
function BreakingNews({ data }: { data: ProjectState }) {
  return (
    <div className="absolute inset-0" style={{ containerType: "size" }}>
      <div className="absolute inset-0" style={{ background: "linear-gradient(180deg, rgba(0,0,0,0.45) 0%, rgba(0,0,0,0.7) 100%)" }} />
      <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-[8cqw] gap-[2cqw]">
        <div className="flex items-center gap-[1cqw] font-mono uppercase tracking-[0.4em] text-[1.05cqw]">
          <span className="px-[1.4cqw] py-[0.55cqw] text-white" style={{ backgroundColor: "#ef2b2b" }}>
            BREAKING NEWS
          </span>
          <span className="text-white/80">· {data.chapter_label}</span>
        </div>
        <h1
          className="font-display text-white leading-[0.9] tracking-tight"
          style={{ fontSize: `${sizePct(data.text_size, 13)}cqw`, textShadow: "0 4px 30px rgba(0,0,0,0.85)" }}
        >
          {data.main_title}
        </h1>
        <div className="h-[3px] w-[18cqw]" style={{ backgroundColor: "#ef2b2b", boxShadow: "0 0 16px rgba(239,43,43,0.6)" }} />
        {data.subtitle && (
          <p className="font-mono text-white/80 uppercase tracking-[0.4em]" style={{ fontSize: `${sizePct(data.text_size, 1.1)}cqw` }}>
            {data.subtitle}
          </p>
        )}
      </div>
    </div>
  );
}