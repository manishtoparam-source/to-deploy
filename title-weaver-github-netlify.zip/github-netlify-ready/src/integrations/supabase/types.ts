export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      brand_kits: {
        Row: {
          background_color: string
          body_font: string
          body_font_family_name: string | null
          body_font_url: string | null
          created_at: string
          heading_font: string
          heading_font_family_name: string | null
          heading_font_url: string | null
          id: string
          logo_opacity: number
          logo_position: string
          logo_size: number
          logo_url: string | null
          name: string
          primary_color: string
          text_color: string
          updated_at: string
          user_id: string
        }
        Insert: {
          background_color?: string
          body_font?: string
          body_font_family_name?: string | null
          body_font_url?: string | null
          created_at?: string
          heading_font?: string
          heading_font_family_name?: string | null
          heading_font_url?: string | null
          id?: string
          logo_opacity?: number
          logo_position?: string
          logo_size?: number
          logo_url?: string | null
          name?: string
          primary_color?: string
          text_color?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          background_color?: string
          body_font?: string
          body_font_family_name?: string | null
          body_font_url?: string | null
          created_at?: string
          heading_font?: string
          heading_font_family_name?: string | null
          heading_font_url?: string | null
          id?: string
          logo_opacity?: number
          logo_position?: string
          logo_size?: number
          logo_url?: string | null
          name?: string
          primary_color?: string
          text_color?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      custom_fonts: {
        Row: {
          created_at: string
          css_url: string | null
          family_name: string
          file_url: string | null
          id: string
          name: string
          source_type: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          css_url?: string | null
          family_name: string
          file_url?: string | null
          id?: string
          name: string
          source_type: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          css_url?: string | null
          family_name?: string
          file_url?: string | null
          id?: string
          name?: string
          source_type?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          created_at: string
          email: string | null
          id: string
          name: string | null
          plan_type: string
        }
        Insert: {
          created_at?: string
          email?: string | null
          id: string
          name?: string | null
          plan_type?: string
        }
        Update: {
          created_at?: string
          email?: string | null
          id?: string
          name?: string | null
          plan_type?: string
        }
        Relationships: []
      }
      projects: {
        Row: {
          aspect_ratio: string
          background_intensity: number
          brand_kit_id: string | null
          camera_movement: string
          chapter_label: string
          created_at: string
          custom_background_url: string | null
          duration: number
          export_resolution: string
          film_grain_enabled: boolean
          highlight_color: string
          id: string
          main_title: string
          mp4_url: string | null
          preview_image_url: string | null
          project_name: string
          render_status: string
          selected_style: string
          subtitle: string | null
          text_size: number
          title_motion: string
          updated_at: string
          user_id: string
          video_url: string | null
        }
        Insert: {
          aspect_ratio?: string
          background_intensity?: number
          brand_kit_id?: string | null
          camera_movement?: string
          chapter_label?: string
          created_at?: string
          custom_background_url?: string | null
          duration?: number
          export_resolution?: string
          film_grain_enabled?: boolean
          highlight_color?: string
          id?: string
          main_title?: string
          mp4_url?: string | null
          preview_image_url?: string | null
          project_name?: string
          render_status?: string
          selected_style?: string
          subtitle?: string | null
          text_size?: number
          title_motion?: string
          updated_at?: string
          user_id: string
          video_url?: string | null
        }
        Update: {
          aspect_ratio?: string
          background_intensity?: number
          brand_kit_id?: string | null
          camera_movement?: string
          chapter_label?: string
          created_at?: string
          custom_background_url?: string | null
          duration?: number
          export_resolution?: string
          film_grain_enabled?: boolean
          highlight_color?: string
          id?: string
          main_title?: string
          mp4_url?: string | null
          preview_image_url?: string | null
          project_name?: string
          render_status?: string
          selected_style?: string
          subtitle?: string | null
          text_size?: number
          title_motion?: string
          updated_at?: string
          user_id?: string
          video_url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "projects_brand_kit_id_fkey"
            columns: ["brand_kit_id"]
            isOneToOne: false
            referencedRelation: "brand_kits"
            referencedColumns: ["id"]
          },
        ]
      }
      render_jobs: {
        Row: {
          completed_at: string | null
          created_at: string
          error_message: string | null
          id: string
          output_url: string | null
          project_id: string
          status: string
          user_id: string
        }
        Insert: {
          completed_at?: string | null
          created_at?: string
          error_message?: string | null
          id?: string
          output_url?: string | null
          project_id: string
          status?: string
          user_id: string
        }
        Update: {
          completed_at?: string | null
          created_at?: string
          error_message?: string | null
          id?: string
          output_url?: string | null
          project_id?: string
          status?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "render_jobs_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      templates: {
        Row: {
          animation_type: string | null
          background_style: string | null
          category: string | null
          created_at: string
          default_color: string | null
          default_font: string | null
          id: string
          is_active: boolean
          slug: string
          sort_order: number
          template_name: string
          thumbnail_url: string | null
        }
        Insert: {
          animation_type?: string | null
          background_style?: string | null
          category?: string | null
          created_at?: string
          default_color?: string | null
          default_font?: string | null
          id?: string
          is_active?: boolean
          slug: string
          sort_order?: number
          template_name: string
          thumbnail_url?: string | null
        }
        Update: {
          animation_type?: string | null
          background_style?: string | null
          category?: string | null
          created_at?: string
          default_color?: string | null
          default_font?: string | null
          id?: string
          is_active?: boolean
          slug?: string
          sort_order?: number
          template_name?: string
          thumbnail_url?: string | null
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
