import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Plus, Trash2, Copy, LogOut, Pencil, Palette } from "lucide-react";
import {
  listProjects, createProject, deleteProject, duplicateProject,
} from "@/lib/projects.functions";
import { Logo } from "@/components/branding/Logo";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { TEMPLATES } from "@/lib/templates";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [{ title: "Your Projects — Chapter Title Generator" }] }),
  component: Dashboard,
});

function Dashboard() {
  const list = useServerFn(listProjects);
  const create = useServerFn(createProject);
  const del = useServerFn(deleteProject);
  const dup = useServerFn(duplicateProject);
  const router = useRouter();
  const qc = useQueryClient();

  const { data: projects, isLoading } = useQuery({ queryKey: ["projects"], queryFn: () => list() });

  const createMut = useMutation({
    mutationFn: () => create({ data: {} as any }),
    onSuccess: (p: any) => router.navigate({ to: "/editor/$projectId", params: { projectId: p.id } }),
    onError: (e: any) => toast.error(e.message),
  });
  const delMut = useMutation({
    mutationFn: (id: string) => del({ data: { id } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["projects"] }),
  });
  const dupMut = useMutation({
    mutationFn: (id: string) => dup({ data: { id } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["projects"] }),
  });

  async function signOut() {
    await qc.cancelQueries(); qc.clear();
    await supabase.auth.signOut();
    router.navigate({ to: "/auth", replace: true });
  }

  return (
    <div className="min-h-screen">
      <header className="border-b border-border px-6 lg:px-10 py-4 flex items-center justify-between">
        <Logo />
        <div className="flex items-center gap-2">
          <Link to="/brand-kits">
            <Button variant="outline" className="border-border bg-surface">
              <Palette className="size-4 mr-1.5" /> Brand kits
            </Button>
          </Link>
          <Button onClick={() => createMut.mutate()} disabled={createMut.isPending} className="bg-neon text-neon-foreground hover:bg-neon/90">
            <Plus className="size-4 mr-1.5" /> New project
          </Button>
          <Button variant="outline" size="icon" onClick={signOut} className="border-border bg-surface" title="Sign out">
            <LogOut className="size-4" />
          </Button>
        </div>
      </header>
      <main className="max-w-6xl mx-auto px-6 lg:px-10 py-10">
        <h1 className="font-display text-4xl mb-1">Your projects</h1>
        <p className="text-muted-foreground text-sm mb-8">Pick up where you left off, or start a new chapter card.</p>

        {isLoading ? (
          <div className="text-muted-foreground">Loading…</div>
        ) : !projects || projects.length === 0 ? (
          <button onClick={() => createMut.mutate()} className="w-full rounded-2xl border border-dashed border-border bg-surface/40 p-16 text-center hover:border-neon transition-colors">
            <Plus className="size-8 mx-auto text-neon" />
            <div className="mt-3 font-semibold">Create your first chapter card</div>
            <div className="text-sm text-muted-foreground mt-1">Loaded with defaults you can edit immediately.</div>
          </button>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {projects.map((p: any) => {
              const tpl = TEMPLATES.find((t) => t.slug === p.selected_style);
              return (
                <div key={p.id} className="rounded-2xl border border-border bg-surface overflow-hidden group">
                  <Link to="/editor/$projectId" params={{ projectId: p.id }} className="block aspect-video relative bg-black">
                    {p.preview_image_url ? (
                      <img src={p.preview_image_url} alt={p.main_title} className="absolute inset-0 w-full h-full object-cover" />
                    ) : (
                      <div className="absolute inset-0 flex flex-col items-center justify-center">
                        <div className="font-mono text-[10px] tracking-[0.3em] text-neon">{p.chapter_label}</div>
                        <div className="font-display text-2xl mt-1 text-white">{p.main_title}</div>
                      </div>
                    )}
                  </Link>
                  <div className="p-4 flex items-center justify-between">
                    <div className="min-w-0">
                      <div className="font-semibold truncate">{p.project_name}</div>
                      <div className="text-xs text-muted-foreground">{tpl?.name ?? p.selected_style}</div>
                    </div>
                    <div className="flex gap-1 shrink-0">
                      <Link to="/editor/$projectId" params={{ projectId: p.id }} className="size-8 grid place-items-center rounded-md hover:bg-surface-2" title="Edit">
                        <Pencil className="size-4" />
                      </Link>
                      <button onClick={() => dupMut.mutate(p.id)} className="size-8 grid place-items-center rounded-md hover:bg-surface-2" title="Duplicate">
                        <Copy className="size-4" />
                      </button>
                      <button onClick={() => { if (confirm("Delete project?")) delMut.mutate(p.id); }} className="size-8 grid place-items-center rounded-md hover:bg-destructive/20 text-destructive" title="Delete">
                        <Trash2 className="size-4" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </main>
    </div>
  );
}