import { createFileRoute } from "@tanstack/react-router";
import { Editor } from "@/components/editor/Editor";

export const Route = createFileRoute("/_authenticated/editor/$projectId")({
  head: () => ({ meta: [{ title: "Editor — Chapter Title Generator" }] }),
  component: () => {
    const { projectId } = Route.useParams();
    return <Editor projectId={projectId} />;
  },
});