import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useRef, useState } from "react";
import { ArrowLeft, Plus, Trash2, Save, Upload, Loader2, Image as ImageIcon, Type, Link2, X } from "lucide-react";
import { toast } from "sonner";

import { listBrandKits, createBrandKit, updateBrandKit, deleteBrandKit } from "@/lib/brand-kits.functions";
import { listCustomFonts, createCustomFont, deleteCustomFont } from "@/lib/custom-fonts.functions";
import { supabase } from "@/integrations/supabase/client";
import { Logo } from "@/components/branding/Logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue, SelectGroup, SelectLabel } from "@/components/ui/select";
import { GOOGLE_FONTS, loadGoogleFont, loadCustomFont, loadSavedFont, type SavedFontRow } from "@/lib/google-fonts";

export const Route = createFileRoute("/_authenticated/brand-kits")({
  head: () => ({ meta: [{ title: "Brand Kits — Chapter Title Generator" }] }),
  component: BrandKitsPage,
});

type Kit = any;

const LOGO_POSITIONS = ["top-left", "top-right", "bottom-left", "bottom-right"] as const;

function BrandKitsPage() {
  const list = useServerFn(listBrandKits);
  const create = useServerFn(createBrandKit);
  const update = useServerFn(updateBrandKit);
  const del = useServerFn(deleteBrandKit);
  const qc = useQueryClient();

  const { data: kits, isLoading } = useQuery({ queryKey: ["brand-kits"], queryFn: () => list() });

  const listFonts = useServerFn(listCustomFonts);
  const { data: savedFonts } = useQuery({ queryKey: ["custom-fonts"], queryFn: () => listFonts() });

  // Pre-load all saved fonts so they're available in pickers & previews
  useEffect(() => {
    (savedFonts as SavedFontRow[] | undefined)?.forEach((f) => loadSavedFont(f));
  }, [savedFonts]);

  const [selectedId, setSelectedId] = useState<string | null>(null);
  useEffect(() => {
    if (!selectedId && kits && (kits as Kit[]).length) setSelectedId((kits as Kit[])[0].id);
  }, [kits, selectedId]);

  const createMut = useMutation({
    mutationFn: () => create({ data: { name: "Untitled Brand Kit" } as any }),
    onSuccess: (k: any) => {
      qc.invalidateQueries({ queryKey: ["brand-kits"] });
      setSelectedId(k.id);
    },
    onError: (e: any) => toast.error(e.message),
  });

  const delMut = useMutation({
    mutationFn: (id: string) => del({ data: { id } }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["brand-kits"] });
      setSelectedId(null);
    },
  });

  const selected: Kit | undefined = (kits as Kit[] | undefined)?.find((k) => k.id === selectedId);

  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b border-border px-6 lg:px-10 py-4 flex items-center justify-between bg-surface/40">
        <div className="flex items-center gap-4">
          <Link to="/dashboard" className="size-9 grid place-items-center rounded-md hover:bg-surface-2"><ArrowLeft className="size-4" /></Link>
          <Logo />
          <h1 className="font-display text-2xl">Brand Kits</h1>
        </div>
        <Button onClick={() => createMut.mutate()} className="bg-neon text-neon-foreground hover:bg-neon/90">
          <Plus className="size-4 mr-1.5" /> New brand kit
        </Button>
      </header>

      <main className="flex-1 grid lg:grid-cols-[280px_minmax(0,1fr)] min-h-0">
        <aside className="border-r border-border bg-surface/30 p-4 overflow-y-auto space-y-2">
          {isLoading && <div className="text-muted-foreground text-sm">Loading…</div>}
          {!isLoading && (!kits || (kits as Kit[]).length === 0) && (
            <div className="text-sm text-muted-foreground p-4 border border-dashed border-border rounded-lg text-center">
              No brand kits yet. Click <span className="text-neon">New brand kit</span> to create one.
            </div>
          )}
          {(kits as Kit[] | undefined)?.map((k) => (
            <button
              key={k.id}
              onClick={() => setSelectedId(k.id)}
              className={`w-full text-left rounded-lg border px-3 py-2.5 flex items-center justify-between gap-2 transition-colors ${
                selectedId === k.id ? "border-neon bg-surface" : "border-border hover:bg-surface-2"
              }`}
            >
              <span className="flex items-center gap-2 min-w-0">
                <span className="size-3 rounded-full shrink-0" style={{ backgroundColor: k.primary_color }} />
                <span className="truncate">{k.name}</span>
              </span>
              {k.logo_url && <ImageIcon className="size-3.5 text-muted-foreground shrink-0" />}
            </button>
          ))}
        </aside>

        <section className="p-6 lg:p-8 overflow-y-auto">
          <FontLibrary />
          {selected ? (
            <KitEditor
              key={selected.id}
              kit={selected}
              savedFonts={(savedFonts as SavedFontRow[] | undefined) ?? []}
              onSave={async (patch) => {
                await update({ data: { id: selected.id, patch } });
                qc.invalidateQueries({ queryKey: ["brand-kits"] });
                toast.success("Brand kit saved");
              }}
              onDelete={() => {
                if (confirm("Delete this brand kit?")) delMut.mutate(selected.id);
              }}
            />
          ) : (
            <div className="text-muted-foreground mt-6">Select a brand kit on the left, or create a new one.</div>
          )}
        </section>
      </main>
    </div>
  );
}

function KitEditor({ kit, savedFonts, onSave, onDelete }: { kit: Kit; savedFonts: SavedFontRow[]; onSave: (patch: any) => Promise<void>; onDelete: () => void }) {
  const [s, setS] = useState<Kit>(kit);
  const [busy, setBusy] = useState(false);

  function set<K extends keyof Kit>(k: K, v: Kit[K]) {
    setS((prev: Kit) => ({ ...prev, [k]: v }));
  }

  // Live-load fonts in the preview panel
  useEffect(() => {
    if (s.heading_font_url) loadCustomFont(s.heading_font_family_name || "BrandHeading", s.heading_font_url);
    else if (s.heading_font) loadGoogleFont(s.heading_font);
    if (s.body_font_url) loadCustomFont(s.body_font_family_name || "BrandBody", s.body_font_url);
    else if (s.body_font) loadGoogleFont(s.body_font);
  }, [s.heading_font, s.body_font, s.heading_font_url, s.body_font_url, s.heading_font_family_name, s.body_font_family_name]);

  async function uploadAsset(file: File, kind: "fonts" | "logos"): Promise<string> {
    const { data: u } = await supabase.auth.getUser();
    const userId = u.user!.id;
    const safe = file.name.replace(/[^a-zA-Z0-9._-]/g, "_");
    const path = `${userId}/${kit.id}/${kind}/${Date.now()}-${safe}`;
    const up = await supabase.storage.from("brand-assets").upload(path, file, { upsert: true, contentType: file.type || undefined });
    if (up.error) throw up.error;
    const signed = await supabase.storage.from("brand-assets").createSignedUrl(path, 60 * 60 * 24 * 365);
    if (signed.error) throw signed.error;
    return signed.data.signedUrl;
  }

  async function handleFontUpload(slot: "heading" | "body", file: File) {
    try {
      setBusy(true);
      const url = await uploadAsset(file, "fonts");
      const familyName = `${slot}-${kit.id.slice(0, 8)}-${Date.now()}`;
      await loadCustomFont(familyName, url);
      if (slot === "heading") {
        set("heading_font_url" as any, url);
        set("heading_font_family_name" as any, familyName);
      } else {
        set("body_font_url" as any, url);
        set("body_font_family_name" as any, familyName);
      }
      toast.success("Font uploaded");
    } catch (e: any) {
      toast.error(e.message ?? "Font upload failed");
    } finally {
      setBusy(false);
    }
  }

  async function handleLogoUpload(file: File) {
    try {
      setBusy(true);
      const url = await uploadAsset(file, "logos");
      set("logo_url" as any, url);
      toast.success("Logo uploaded");
    } catch (e: any) {
      toast.error(e.message ?? "Logo upload failed");
    } finally {
      setBusy(false);
    }
  }

  async function handleSave() {
    setBusy(true);
    try {
      const { id: _id, user_id: _u, created_at: _c, updated_at: _ud, ...rest } = s as any;
      await onSave(rest);
    } catch (e: any) {
      toast.error(e.message ?? "Save failed");
    } finally {
      setBusy(false);
    }
  }

  const headingFamily = s.heading_font_url
    ? `"${s.heading_font_family_name || "BrandHeading"}"`
    : `"${s.heading_font}"`;
  const bodyFamily = s.body_font_url
    ? `"${s.body_font_family_name || "BrandBody"}"`
    : `"${s.body_font}"`;

  return (
    <div className="grid lg:grid-cols-[minmax(0,1fr)_380px] gap-8 max-w-6xl">
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Input value={s.name} onChange={(e) => set("name", e.target.value)} className="bg-surface border-border text-lg font-semibold h-11 max-w-sm" />
          <Button onClick={handleSave} disabled={busy} className="bg-neon text-neon-foreground hover:bg-neon/90">
            {busy ? <Loader2 className="size-4 mr-1.5 animate-spin" /> : <Save className="size-4 mr-1.5" />} Save
          </Button>
          <Button onClick={onDelete} variant="ghost" className="text-destructive hover:text-destructive">
            <Trash2 className="size-4 mr-1.5" /> Delete
          </Button>
        </div>

        <Section title="Colors">
          <div className="grid sm:grid-cols-3 gap-3">
            <ColorField label="Primary / Highlight" value={s.primary_color} onChange={(v) => set("primary_color", v)} />
            <ColorField label="Background" value={s.background_color} onChange={(v) => set("background_color", v)} />
            <ColorField label="Text" value={s.text_color} onChange={(v) => set("text_color", v)} />
          </div>
        </Section>

        <Section title="Fonts">
          <FontPicker
            label="Heading font"
            googleFont={s.heading_font}
            customUrl={s.heading_font_url}
            customName={s.heading_font_family_name}
            savedFonts={savedFonts}
            onGoogleChange={(v) => { set("heading_font", v); set("heading_font_url" as any, null); set("heading_font_family_name" as any, null); }}
            onClearCustom={() => { set("heading_font_url" as any, null); set("heading_font_family_name" as any, null); }}
            onUpload={(f) => handleFontUpload("heading", f)}
            onPickSaved={(f) => {
              loadSavedFont(f);
              set("heading_font", f.family_name);
              set("heading_font_url" as any, f.source_type === "css_url" ? null : f.file_url);
              set("heading_font_family_name" as any, f.family_name);
            }}
          />
          <FontPicker
            label="Body font"
            googleFont={s.body_font}
            customUrl={s.body_font_url}
            customName={s.body_font_family_name}
            savedFonts={savedFonts}
            onGoogleChange={(v) => { set("body_font", v); set("body_font_url" as any, null); set("body_font_family_name" as any, null); }}
            onClearCustom={() => { set("body_font_url" as any, null); set("body_font_family_name" as any, null); }}
            onUpload={(f) => handleFontUpload("body", f)}
            onPickSaved={(f) => {
              loadSavedFont(f);
              set("body_font", f.family_name);
              set("body_font_url" as any, f.source_type === "css_url" ? null : f.file_url);
              set("body_font_family_name" as any, f.family_name);
            }}
          />
        </Section>

        <Section title="Logo overlay">
          <LogoUploadField logoUrl={s.logo_url} onUpload={handleLogoUpload} onClear={() => set("logo_url" as any, null)} />
          {s.logo_url && (
            <div className="grid sm:grid-cols-3 gap-4 mt-4">
              <div className="space-y-1.5">
                <Label className="text-xs uppercase tracking-widest text-muted-foreground">Position</Label>
                <Select value={s.logo_position} onValueChange={(v) => set("logo_position", v)}>
                  <SelectTrigger className="bg-background border-border"><SelectValue /></SelectTrigger>
                  <SelectContent>{LOGO_POSITIONS.map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between"><Label className="text-xs uppercase tracking-widest text-muted-foreground">Size</Label><span className="text-xs font-mono">{s.logo_size}%</span></div>
                <Slider value={[s.logo_size]} onValueChange={([v]) => set("logo_size", v)} min={4} max={40} step={1} />
              </div>
              <div className="space-y-2">
                <div className="flex justify-between"><Label className="text-xs uppercase tracking-widest text-muted-foreground">Opacity</Label><span className="text-xs font-mono">{s.logo_opacity}%</span></div>
                <Slider value={[s.logo_opacity]} onValueChange={([v]) => set("logo_opacity", v)} min={10} max={100} step={1} />
              </div>
            </div>
          )}
        </Section>
      </div>

      {/* Live preview */}
      <div className="space-y-3">
        <div className="text-xs uppercase tracking-[0.4em] text-muted-foreground font-mono">Preview</div>
        <div
          className="aspect-video rounded-xl overflow-hidden border border-border relative"
          style={{ backgroundColor: s.background_color }}
        >
          {s.logo_url && (
            <img
              src={s.logo_url}
              alt=""
              style={{
                position: "absolute",
                [s.logo_position.startsWith("top") ? "top" : "bottom"]: "4%",
                [s.logo_position.endsWith("left") ? "left" : "right"]: "4%",
                width: `${s.logo_size}%`,
                opacity: s.logo_opacity / 100,
                objectFit: "contain",
              }}
            />
          )}
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-6 gap-3">
            <div
              className="text-[10px] tracking-[0.5em] uppercase px-2 py-1 inline-block border-2"
              style={{ color: s.primary_color, borderColor: s.primary_color, fontFamily: bodyFamily }}
            >
              CHAPTER 03
            </div>
            <div className="text-5xl leading-[0.9] uppercase" style={{ color: s.text_color, fontFamily: headingFamily }}>
              The Collapse
            </div>
            <div className="text-xs tracking-[0.3em] uppercase opacity-70" style={{ color: s.text_color, fontFamily: bodyFamily }}>
              A documentary in five parts
            </div>
          </div>
        </div>
        <p className="text-xs text-muted-foreground">Apply this kit on the editor's Brand kit dropdown.</p>
      </div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-xl border border-border bg-surface/40 p-5 space-y-3">
      <div className="text-sm font-semibold">{title}</div>
      {children}
    </div>
  );
}

function FontLibrary() {
  const listFonts = useServerFn(listCustomFonts);
  const createFont = useServerFn(createCustomFont);
  const delFont = useServerFn(deleteCustomFont);
  const qc = useQueryClient();
  const { data: fonts } = useQuery({ queryKey: ["custom-fonts"], queryFn: () => listFonts() });

  const [open, setOpen] = useState(false);
  const [mode, setMode] = useState<"upload" | "file_url" | "css_url">("css_url");
  const [name, setName] = useState("");
  const [familyName, setFamilyName] = useState("");
  const [url, setUrl] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  function reset() {
    setName(""); setFamilyName(""); setUrl(""); setFile(null); setMode("css_url");
  }

  async function uploadFile(f: File): Promise<string> {
    const { data: u } = await supabase.auth.getUser();
    const userId = u.user!.id;
    const safe = f.name.replace(/[^a-zA-Z0-9._-]/g, "_");
    const path = `${userId}/library/${Date.now()}-${safe}`;
    const up = await supabase.storage.from("brand-assets").upload(path, f, { upsert: true, contentType: f.type || undefined });
    if (up.error) throw up.error;
    const signed = await supabase.storage.from("brand-assets").createSignedUrl(path, 60 * 60 * 24 * 365 * 10);
    if (signed.error) throw signed.error;
    return signed.data.signedUrl;
  }

  async function handleSave() {
    if (!name.trim()) return toast.error("Give the font a name");
    setBusy(true);
    try {
      let payload: any = { name: name.trim(), family_name: familyName.trim() || name.trim(), source_type: mode };
      if (mode === "upload") {
        if (!file) throw new Error("Pick a font file");
        payload.file_url = await uploadFile(file);
      } else if (mode === "file_url") {
        if (!url.trim()) throw new Error("Paste the font file URL");
        payload.file_url = url.trim();
      } else {
        if (!url.trim()) throw new Error("Paste the stylesheet URL");
        payload.css_url = url.trim();
        if (!familyName.trim()) throw new Error("Family name is required for stylesheet imports");
      }
      const row = await createFont({ data: payload });
      loadSavedFont(row as SavedFontRow);
      qc.invalidateQueries({ queryKey: ["custom-fonts"] });
      toast.success("Font saved to library");
      reset();
      setOpen(false);
    } catch (e: any) {
      toast.error(e.message ?? "Could not save font");
    } finally {
      setBusy(false);
    }
  }

  async function handleDelete(id: string) {
    if (!confirm("Remove this font from your library?")) return;
    await delFont({ data: { id } });
    qc.invalidateQueries({ queryKey: ["custom-fonts"] });
  }

  const list = (fonts as SavedFontRow[] | undefined) ?? [];

  return (
    <div className="rounded-xl border border-border bg-surface/40 p-5 mb-6 max-w-6xl">
      <div className="flex items-center justify-between mb-3">
        <div>
          <div className="text-sm font-semibold">Font library</div>
          <div className="text-xs text-muted-foreground">Upload font files, paste a font URL, or import a Google/Fontshare stylesheet — reuse across every brand kit.</div>
        </div>
        <Button size="sm" onClick={() => setOpen((o) => !o)} className="bg-neon text-neon-foreground hover:bg-neon/90">
          {open ? <X className="size-4 mr-1.5" /> : <Plus className="size-4 mr-1.5" />} {open ? "Cancel" : "Add font"}
        </Button>
      </div>

      {open && (
        <div className="rounded-lg border border-border bg-background p-4 space-y-3 mb-4">
          <div className="flex gap-2">
            {(["css_url", "file_url", "upload"] as const).map((m) => (
              <button
                key={m}
                onClick={() => setMode(m)}
                className={`text-xs px-3 py-1.5 rounded-md border ${mode === m ? "bg-neon text-neon-foreground border-neon" : "border-border bg-surface hover:bg-surface-2"}`}
              >
                {m === "css_url" ? "Stylesheet URL" : m === "file_url" ? "Font file URL" : "Upload file"}
              </button>
            ))}
          </div>

          <div className="grid sm:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label className="text-xs uppercase tracking-widest text-muted-foreground">Display name</Label>
              <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Studio Heading" className="bg-surface border-border" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs uppercase tracking-widest text-muted-foreground">
                Family name {mode === "css_url" && <span className="text-destructive">*</span>}
              </Label>
              <Input
                value={familyName}
                onChange={(e) => setFamilyName(e.target.value)}
                placeholder={mode === "css_url" ? "Must match CSS @font-face family" : "Optional — defaults to display name"}
                className="bg-surface border-border font-mono"
              />
            </div>
          </div>

          {mode === "upload" ? (
            <div className="flex items-center gap-2">
              <Button variant="outline" className="border-border bg-surface" onClick={() => fileRef.current?.click()}>
                <Upload className="size-4 mr-1.5" /> {file ? "Replace file" : "Choose .ttf/.otf/.woff"}
              </Button>
              {file && <span className="text-xs text-muted-foreground truncate">{file.name}</span>}
              <input
                ref={fileRef}
                type="file"
                accept=".ttf,.otf,.woff,.woff2"
                className="hidden"
                onChange={(e) => { setFile(e.target.files?.[0] ?? null); e.target.value = ""; }}
              />
            </div>
          ) : (
            <div className="space-y-1.5">
              <Label className="text-xs uppercase tracking-widest text-muted-foreground">
                {mode === "css_url" ? "Stylesheet URL (Google Fonts, Fontshare, Adobe…)" : "Direct font file URL (.woff2/.ttf/.otf)"}
              </Label>
              <div className="flex items-center gap-2">
                <Link2 className="size-4 text-muted-foreground" />
                <Input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://…" className="bg-surface border-border font-mono text-xs" />
              </div>
            </div>
          )}

          <div className="flex justify-end">
            <Button onClick={handleSave} disabled={busy} className="bg-neon text-neon-foreground hover:bg-neon/90">
              {busy ? <Loader2 className="size-4 mr-1.5 animate-spin" /> : <Save className="size-4 mr-1.5" />} Save to library
            </Button>
          </div>
        </div>
      )}

      {list.length === 0 ? (
        <div className="text-xs text-muted-foreground py-3 text-center border border-dashed border-border rounded-lg">
          No saved fonts yet. Add one above to reuse it across every brand kit and project.
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-2">
          {list.map((f) => (
            <SavedFontCard key={f.id} font={f} onDelete={() => handleDelete(f.id)} />
          ))}
        </div>
      )}
    </div>
  );
}

function SavedFontCard({ font, onDelete }: { font: SavedFontRow; onDelete: () => void }) {
  useEffect(() => { loadSavedFont(font); }, [font]);
  return (
    <div className="rounded-lg border border-border bg-background px-3 py-2.5 flex items-center justify-between gap-2">
      <div className="min-w-0">
        <div className="text-base truncate" style={{ fontFamily: `"${font.family_name}"` }}>{font.name}</div>
        <div className="text-[10px] text-muted-foreground uppercase tracking-widest font-mono">
          {font.source_type === "css_url" ? "Stylesheet" : font.source_type === "file_url" ? "URL" : "Upload"}
        </div>
      </div>
      <Button variant="ghost" size="icon" className="shrink-0 text-muted-foreground hover:text-destructive" onClick={onDelete}>
        <Trash2 className="size-4" />
      </Button>
    </div>
  );
}

function ColorField({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs uppercase tracking-widest text-muted-foreground">{label}</Label>
      <div className="flex items-center gap-2">
        <input type="color" value={value} onChange={(e) => onChange(e.target.value)} className="size-9 rounded-md border border-border bg-transparent cursor-pointer" />
        <Input value={value} onChange={(e) => onChange(e.target.value)} className="bg-background border-border font-mono" />
      </div>
    </div>
  );
}

function FontPicker({
  label,
  googleFont,
  customUrl,
  customName,
  savedFonts,
  onGoogleChange,
  onClearCustom,
  onUpload,
  onPickSaved,
}: {
  label: string;
  googleFont: string;
  customUrl: string | null;
  customName: string | null;
  savedFonts: SavedFontRow[];
  onGoogleChange: (v: string) => void;
  onClearCustom: () => void;
  onUpload: (f: File) => void;
  onPickSaved: (f: SavedFontRow) => void;
}) {
  const fileRef = useRef<HTMLInputElement>(null);
  const usingCustom = !!customUrl;
  return (
    <div className="space-y-2">
      <Label className="text-xs uppercase tracking-widest text-muted-foreground">{label}</Label>
      {usingCustom ? (
        <div className="flex items-center justify-between rounded-lg border border-border bg-background px-3 py-2.5">
          <div className="flex items-center gap-2 min-w-0">
            <Type className="size-4 text-neon shrink-0" />
            <div className="min-w-0">
              <div className="text-sm truncate">Custom font</div>
              <div className="text-[10px] text-muted-foreground font-mono truncate">{customName}</div>
            </div>
          </div>
          <Button variant="ghost" size="sm" onClick={onClearCustom}>Use Google Font</Button>
        </div>
      ) : (
        <div className="flex gap-2">
          <Select
            value={googleFont}
            onValueChange={(v) => {
              if (v.startsWith("saved:")) {
                const f = savedFonts.find((x) => x.id === v.slice(6));
                if (f) onPickSaved(f);
              } else {
                onGoogleChange(v);
              }
            }}
          >
            <SelectTrigger className="bg-background border-border"><SelectValue /></SelectTrigger>
            <SelectContent className="max-h-72">
              {savedFonts.length > 0 && (
                <SelectGroup>
                  <SelectLabel>Your library</SelectLabel>
                  {savedFonts.map((f) => (
                    <SelectItem key={f.id} value={`saved:${f.id}`}>
                      <span style={{ fontFamily: `"${f.family_name}"` }}>{f.name}</span>
                    </SelectItem>
                  ))}
                </SelectGroup>
              )}
              <SelectGroup>
                <SelectLabel>Google Fonts</SelectLabel>
                {GOOGLE_FONTS.map((f) => (
                  <SelectItem key={f} value={f}><span style={{ fontFamily: `"${f}"` }}>{f}</span></SelectItem>
                ))}
              </SelectGroup>
            </SelectContent>
          </Select>
          <Button type="button" variant="outline" className="border-border bg-background shrink-0" onClick={() => fileRef.current?.click()}>
            <Upload className="size-4 mr-1.5" /> Upload
          </Button>
          <input
            ref={fileRef}
            type="file"
            accept=".ttf,.otf,.woff,.woff2,font/ttf,font/otf,font/woff,font/woff2"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) onUpload(f);
              e.target.value = "";
            }}
          />
        </div>
      )}
    </div>
  );
}

function LogoUploadField({ logoUrl, onUpload, onClear }: { logoUrl: string | null; onUpload: (f: File) => void; onClear: () => void }) {
  const fileRef = useRef<HTMLInputElement>(null);
  return (
    <div className="flex items-center gap-4">
      <div className="size-24 rounded-lg border border-border bg-background grid place-items-center overflow-hidden">
        {logoUrl ? <img src={logoUrl} alt="" className="max-w-full max-h-full object-contain" /> : <ImageIcon className="size-6 text-muted-foreground" />}
      </div>
      <div className="space-x-2">
        <Button variant="outline" className="border-border bg-background" onClick={() => fileRef.current?.click()}>
          <Upload className="size-4 mr-1.5" /> {logoUrl ? "Replace" : "Upload logo"}
        </Button>
        {logoUrl && <Button variant="ghost" onClick={onClear}>Remove</Button>}
        <input
          ref={fileRef}
          type="file"
          accept="image/png,image/jpeg,image/webp,image/svg+xml"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) onUpload(f);
            e.target.value = "";
          }}
        />
      </div>
    </div>
  );
}