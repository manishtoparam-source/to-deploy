import { createFileRoute } from "@tanstack/react-router";
import { Link } from "@tanstack/react-router";
import { Film, Play, Sparkles, Download } from "lucide-react";
import { Logo } from "@/components/branding/Logo";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Chapter Title Generator — Cinematic title cards for video creators" },
      { name: "description", content: "Design and export cinematic chapter title animations for YouTube documentaries, reels, and storytelling videos." },
      { property: "og:title", content: "Chapter Title Generator" },
      { property: "og:description", content: "Design and export cinematic chapter title animations for video creators." },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="flex items-center justify-between px-6 lg:px-10 py-5 border-b border-border">
        <Logo />
        <div className="flex items-center gap-3">
          <Link to="/auth" className="text-sm text-muted-foreground hover:text-foreground">Sign in</Link>
          <Link to="/auth" className="bg-neon text-neon-foreground font-semibold text-sm px-4 py-2 rounded-full shadow-neon">
            Start free
          </Link>
        </div>
      </header>
      <section className="px-6 lg:px-10 pt-20 pb-28 max-w-6xl mx-auto text-center">
        <div className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.3em] text-neon font-mono mb-6">
          <span className="size-1.5 rounded-full bg-neon" /> cinematic title cards
        </div>
        <h1 className="font-display text-5xl md:text-7xl lg:text-8xl leading-[0.95]">
          Make every chapter feel<br />
          <span className="text-neon">like a film opening.</span>
        </h1>
        <p className="mt-6 text-lg text-muted-foreground max-w-2xl mx-auto">
          Drop in a title, pick a style, hit render. Get high-resolution chapter title videos for
          documentaries, reels, and long-form YouTube — in seconds.
        </p>
        <div className="mt-10 flex items-center justify-center gap-3">
          <Link to="/auth" className="bg-neon text-neon-foreground font-semibold px-6 py-3 rounded-full shadow-neon inline-flex items-center gap-2">
            <Play className="size-4" /> Open the editor
          </Link>
          <a href="#features" className="px-6 py-3 rounded-full border border-border text-sm">See how it works</a>
        </div>

        <div className="mt-20 rounded-3xl border border-border bg-surface aspect-video relative overflow-hidden shadow-neon">
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <div className="font-mono text-xs tracking-[0.4em] text-neon border border-neon px-3 py-1 -rotate-2">CHAPTER 03</div>
            <h2 className="font-display text-white text-6xl md:text-8xl mt-4">THE COLLAPSE</h2>
          </div>
          <div className="absolute inset-0 film-grain opacity-50" />
        </div>
      </section>
      <section id="features" className="border-t border-border bg-surface/30">
        <div className="max-w-6xl mx-auto px-6 lg:px-10 py-20 grid md:grid-cols-4 gap-6">
          {[
            { i: Film, t: "Professional chapter animations", d: "10 cinematic templates engineered for motion." },
            { i: Sparkles, t: "Boost video retention", d: "Pattern interrupts that hold attention." },
            { i: Play, t: "Perfect for YouTube", d: "Aspect ratios from 16:9 to 9:16 reels." },
            { i: Download, t: "Export in high quality", d: "Crisp WebM video + PNG poster." },
          ].map(({ i: Icon, t, d }) => (
            <div key={t} className="rounded-2xl border border-border bg-surface p-6">
              <Icon className="size-5 text-neon mb-3" />
              <div className="font-semibold">{t}</div>
              <div className="text-sm text-muted-foreground mt-1">{d}</div>
            </div>
          ))}
        </div>
      </section>
      <footer className="border-t border-border py-8 px-6 lg:px-10 text-sm text-muted-foreground flex items-center justify-between">
        <Logo small />
        <div>© {new Date().getFullYear()} Chapter Title Generator</div>
      </footer>
    </div>
  );
}
