# Title Weaver - Mobile App Deployment Guide

## Overview
This guide walks you through deploying your Title Weaver app to Google Play Store and Apple App Store using Capacitor.

---

## Prerequisites

### System Requirements
- **Node.js**: v16+ ([download](https://nodejs.org))
- **npm**: v8+ (comes with Node.js)
- **Git**: [download](https://git-scm.com)

### Accounts & Tools
- **Google Play Developer Account**: $25 one-time fee
- **Apple Developer Account**: $99/year
- **Android Studio**: [download](https://developer.android.com/studio)
- **Xcode**: Mac only ([download from App Store](https://apps.apple.com/us/app/xcode/id497799835))
- **JDK 11+**: For Android builds

### Assets
- App icon: 1024×1024 PNG
- App screenshots: 5-8 per platform (see store requirements)
- Privacy policy URL
- App description (500 chars max)

---

## Step 1: Setup Project Locally

```bash
# Navigate to your project directory
cd ~/path/to/title-weaver

# Install dependencies
npm install

# Build the web app
npm run build

# Verify build succeeded
ls -la dist/
```

---

## Step 2: Initialize Capacitor

```bash
# Install Capacitor globally (optional but recommended)
npm install -g @capacitor/cli

# Install Capacitor packages
npm install @capacitor/core @capacitor/cli @capacitor/android @capacitor/ios \
  @capacitor/splash-screen @capacitor/app @capacitor/keyboard @capacitor/status-bar

# Initialize Capacitor project
npx cap init

# When prompted:
# - App name: Title Weaver
# - App Package ID: com.titleweaver.app
# - Web asset directory: dist
```

---

## Step 3: Add Android Platform

### 3.1 Add Android Platform
```bash
npm run cap:add:android
# Or: npx cap add android
```

### 3.2 Setup Android Environment
```bash
# Install Android Studio if not already installed

# Set environment variables (add to ~/.bashrc or ~/.zshrc):
export ANDROID_SDK_ROOT=$HOME/Library/Android/sdk  # macOS
# OR
export ANDROID_SDK_ROOT=$HOME/Android/Sdk  # Linux

# For Windows, set via System Properties → Environment Variables
```

### 3.3 Create Keystore for Signing
```bash
# Navigate to android app directory
cd android/app

# Generate keystore (keep this file safe!)
keytool -genkey -v -keystore title-weaver.keystore \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias title-weaver-key

# When prompted, enter:
# - Password: (create strong password - save it!)
# - Key password: (same as above)
# - Full name: Your Name
# - Company: Your Company (can be empty)
# - City: Your City
# - State/Province: Your State (2 letters)
# - Country: IN
# - Is correct? yes

# Copy keystore to safe location
cp title-weaver.keystore ~/secure-location/
```

### 3.4 Configure Gradle for Signing
```bash
# Go to android/ directory
cd ../

# Edit build.gradle or create local.properties
# Add to android/local.properties:
sdk.dir=/path/to/Android/sdk
TITLE_WEAVER_KEYSTORE_PATH=../title-weaver.keystore
TITLE_WEAVER_KEYSTORE_PASSWORD=your_password_here
TITLE_WEAVER_KEY_PASSWORD=your_password_here
TITLE_WEAVER_KEY_ALIAS=title-weaver-key
```

### 3.5 Build Release APK/AAB
```bash
# Back to project root
cd ../..

# Build release bundle (for Play Store)
cd android && ./gradlew bundleRelease

# Or build APK (for testing)
./gradlew assembleRelease

# Signed files will be at:
# android/app/build/outputs/bundle/release/app-release.aab
# android/app/build/outputs/apk/release/app-release.apk
```

---

## Step 4: Add iOS Platform

**Note**: iOS development requires a Mac with Xcode installed.

### 4.1 Add iOS Platform
```bash
npm run cap:add:ios
# Or: npx cap add ios
```

### 4.2 Open Xcode Project
```bash
npm run cap:open:ios
# Or: npx cap open ios

# This opens the Xcode project in: ios/App/App.xcworkspace
```

### 4.3 Configure in Xcode
1. Select **App** in left sidebar
2. Go to **General** tab
3. Under **Identity**:
   - Bundle Identifier: `com.titleweaver.app`
   - Version: `1.0.0`
   - Build: `1`

### 4.4 Add App Icon
1. Select **App** → **General**
2. Under **App Icons and Launch Images**, select asset catalog
3. Click **Add Files** → select your 1024×1024 icon
4. Xcode auto-generates all required sizes

### 4.5 Create Archive
```bash
# In Xcode:
# 1. Select "Any iOS Device" from device dropdown
# 2. Product → Archive
# 3. Wait for build to complete
# 4. Window → Organizer → Archives
```

### 4.6 Upload to App Store
```bash
# In Organizer window:
# 1. Select your archive
# 2. Click "Distribute App"
# 3. Select "App Store Connect"
# 4. Follow the prompts
```

---

## Step 5: Submit to Google Play Store

### 5.1 Create Google Play Developer Account
1. Go to [play.google.com/console](https://play.google.com/console)
2. Pay $25 one-time fee
3. Complete account setup

### 5.2 Create New App
1. Click **Create app**
2. App name: `Title Weaver`
3. Default language: English
4. App type: Application
5. Category: Productivity (or appropriate category)

### 5.3 Fill App Details
1. Go to **Store listing**
2. Add:
   - **Title**: Title Weaver (50 chars max)
   - **Short description**: Create stunning title cards
   - **Full description**: (4000 chars max) - describe features, benefits
   - **Screenshots**: 5-8 images (1080×1920 or larger)
   - **Feature graphic**: 1024×500
   - **Category**: Productivity
   - **Content rating**: Complete questionnaire
   - **Target audience**: All ages

### 5.4 Add Privacy Policy
1. Go to **App content**
2. Paste privacy policy URL
3. Declare data collection practices

### 5.5 Create Release
1. Go to **Testing → Internal testing**
2. Click **Create new release**
3. Upload your `app-release.aab` file
4. Add release notes
5. Click **Review release**

### 5.6 Submit for Review
1. Go to **Production**
2. Click **Create new release**
3. Upload your tested AAB file
4. Set version code (increment each release)
5. Click **Save**
6. Review pricing and distribution
7. Click **Submit for review**

**Processing time**: Usually 1-2 hours, rarely up to 24 hours.

---

## Step 6: Submit to Apple App Store

### 6.1 Enroll in Apple Developer Program
1. Go to [developer.apple.com](https://developer.apple.com)
2. Enroll in Apple Developer Program ($99/year)
3. Complete identity verification (1-2 days)

### 6.2 Create App ID
1. Go to [appstoreconnect.apple.com](https://appstoreconnect.apple.com)
2. **My Apps** → **+** icon → **New App**
3. Platform: iOS
4. Name: `Title Weaver`
5. Primary Language: English
6. Bundle ID: `com.titleweaver.app`
7. SKU: `titleweaver2024`
8. User Access: Full Access

### 6.3 Fill App Information
1. **App Information**:
   - Category: Productivity
   - Subtitle: Create stunning title cards
   - Privacy policy URL: (must be HTTPS)

2. **Pricing and Availability**:
   - Price: Free (or set price)
   - Territories: Select all or specific regions

3. **App Preview and Screenshots**:
   - iPhone: 5.5" display (1080×1920)
   - iPad: 12.9" display (2048×2732)
   - Add 2-5 screenshots per device type
   - Add app preview video (optional but recommended)

### 6.4 Create Version Release
1. **Testflight** tab → **Internal Testing**
2. Click **+** → **Create version**
3. Upload your archive from Xcode Organizer
4. Fill in:
   - Version number: `1.0.0`
   - Build: (auto-assigned)
   - What's new: `Initial release`

### 6.5 Complete Build Information
1. Test flight version appears
2. Add test accounts if applicable
3. Click **Add for Testing**

### 6.6 Submit to App Store Review
1. Go to **App Store** tab
2. Version Release Information:
   - Version number: `1.0`
   - Release notes: `Initial release of Title Weaver`
   - Keywords: `title, video, card, editor, branding` (5 max)

3. Build:
   - Select your tested build
   - Confirm all info

4. App Review Information:
   - Notes for reviewers: (leave blank or add helpful info)
   - Contact email: your@email.com
   - Demo account: (if needed)
   - Sign in required: No (unless app requires signup)

5. **Save** → **Submit for Review**

**Processing time**: Usually 1-3 days, occasionally up to 5 days. Apple reviews for:
- App crashes
- Content appropriateness
- Features matching description
- Third-party library compliance

---

## Common Issues & Solutions

### Android: Build Fails with Gradle Error
```bash
# Clean gradle cache
cd android && ./gradlew clean && ./gradlew bundleRelease
```

### Android: Keystore Not Found
- Verify `title-weaver.keystore` path in `local.properties`
- Check file permissions: `chmod 644 title-weaver.keystore`

### iOS: Code Signing Error
1. Xcode → Preferences → Accounts
2. Click Apple ID, then View Details
3. Click refresh button (⟲)
4. Try archiving again

### iOS: Archive Upload Fails
- Check internet connection
- Verify Apple ID has correct permissions
- Try uploading from Xcode Organizer instead

### App Rejected by Apple
Common reasons:
- **Crashes on startup**: Test thoroughly on real device
- **Unclear purpose**: Make description clear and detailed
- **Third-party content**: Ensure all libraries have compatible licenses
- **Data privacy**: Include explicit privacy policy
- **Login not working**: Test auth flow completely

---

## Version Updates

### Releasing Version 2.0

1. **Update version numbers**:
   ```bash
   # Update in package.json, capacitor.config.ts
   ```

2. **Build new release**:
   ```bash
   npm run build
   npm run cap:sync
   ```

3. **Android**:
   - Increment `versionCode` in `android/app/build.gradle`
   - Build new AAB: `cd android && ./gradlew bundleRelease`
   - Upload to Play Store

4. **iOS**:
   - Increment Build version in Xcode
   - Create new archive
   - Upload to App Store Connect

---

## Monitoring & Analytics

### Google Play Store
- **Dashboard**: Real-time metrics on downloads, crashes
- **User feedback**: Reviews and ratings
- **ANRs & crashes**: Built-in crash reporting

### App Store Connect
- **Analytics**: Downloads, crashes, performance
- **User feedback**: Reviews and ratings
- **Sales data**: Revenue tracking (if paid)

---

## Support Resources

- **Capacitor Docs**: https://capacitorjs.com
- **Android Dev**: https://developer.android.com
- **Apple Dev**: https://developer.apple.com
- **Play Store Help**: https://support.google.com/googleplay
- **App Store Help**: https://help.apple.com/app-store-connect

---

## Checklist Before Submission

### General
- [ ] App builds successfully locally
- [ ] No console errors or warnings
- [ ] App works offline (if applicable)
- [ ] All features functional
- [ ] Loading states implemented
- [ ] Error handling complete

### Android
- [ ] Keystore created and backed up
- [ ] APK/AAB signed and verified
- [ ] Tested on Android 8.0+ devices
- [ ] Screenshots ready (1080×1920)
- [ ] Privacy policy HTTPS URL ready

### iOS
- [ ] Tested on iOS 13.0+ devices
- [ ] App icon (1024×1024) added
- [ ] Screenshots ready (5.5" and larger)
- [ ] Privacy policy HTTPS URL ready
- [ ] Bundle ID configured correctly

### Both Platforms
- [ ] App description final
- [ ] Release notes written
- [ ] Privacy policy published
- [ ] Terms of service prepared (if applicable)
- [ ] Support email ready
- [ ] Keywords finalized (5-10 total)

---

## Need Help?

1. Check the Capacitor docs: https://capacitorjs.com/docs
2. Android Studio error logs: **View → Tool Windows → Logcat**
3. Xcode logs: **View → Navigators → Reports**
4. Test on real devices before submitting
5. Join developer communities (Reddit, Stack Overflow, GitHub Discussions)

Good luck with your submission! 🚀
