# Title Weaver - Setup & Deployment Instructions

## 🎉 Welcome!

This is your **Title Weaver** application exported from Lovable with **Capacitor** pre-configured for mobile app deployment to Google Play Store and Apple App Store.

---

## 📋 What You Have

✅ Complete Lovable project with all fixes  
✅ Capacitor configuration  
✅ Step-by-step deployment guides  
✅ Build scripts for Android & iOS  
✅ All source code, assets, and dependencies  

---

## 🚀 Quick Start (Choose Your Path)

### Path A: Local Development Only
If you just want to run the app locally:

```bash
npm install
npm run dev
```

Visit: `http://localhost:5173`

---

### Path B: Deploy to App Stores
If you want to deploy to Google Play & Apple App Store:

**1. Read the guides (in this order):**
1. `README_DEPLOYMENT.md` - 5 min overview
2. `DEPLOYMENT_GUIDE.md` - Complete instructions
3. `QUICK_START.md` - Command reference

**2. Install & Setup:**
```bash
npm install

npm install @capacitor/core @capacitor/cli @capacitor/android @capacitor/ios \
  @capacitor/splash-screen @capacitor/app @capacitor/keyboard @capacitor/status-bar
```

**3. Initialize Capacitor:**
```bash
npx cap init
npm run build
npx cap add android
npx cap add ios
```

**4. Build for stores:**
- **Android:** Follow "Android Build & Deploy" in DEPLOYMENT_GUIDE.md
- **iOS:** Follow "iOS Build & Deploy" in DEPLOYMENT_GUIDE.md

**5. Submit:**
- Upload to Google Play Store
- Upload to Apple App Store

---

## 📂 Project Structure

```
title-weaver/
├── src/                          # Your app code
│   ├── components/              # React components
│   ├── routes/                  # App pages/routes
│   ├── assets/                  # Images, templates
│   ├── lib/                      # Utilities & helpers
│   ├── integrations/            # Supabase, Lovable
│   └── styles.css               # Global styles
├── supabase/                     # Database config
├── public/                       # Static files
├── package.json                 # Dependencies
├── vite.config.ts               # Vite config
├── tsconfig.json                # TypeScript config
├── capacitor.config.ts          # ✨ Capacitor setup
├── DEPLOYMENT_GUIDE.md          # 📖 Full guide
├── QUICK_START.md               # ⚡ Command reference
└── README_DEPLOYMENT.md         # 📖 Overview
```

---

## 🔧 Configuration

### App Details
- **App ID:** `com.titleweaver.app`
- **App Name:** `Title Weaver`
- **Web Directory:** `dist`

Change these in `capacitor.config.ts` if needed.

### Environment Variables
Check `.env` for any required variables (Supabase, API keys, etc.)

---

## 📱 What Each Platform Needs

### Android Requirements
- Google Play Developer Account ($25 one-time)
- Android Studio
- JDK 11+
- Keystore file (generated during build)
- App icon (1024×1024 PNG)
- Screenshots (1080×1920 minimum)

### iOS Requirements
- Apple Developer Account ($99/year)
- Mac with Xcode
- App icon (1024×1024 PNG)
- Screenshots (multiple device sizes)
- Privacy policy URL

---

## ⏱️ Timeline

| Step | Duration |
|------|----------|
| Install & setup | 30-45 min |
| Android build | 2-3 hours |
| iOS build | 2-3 hours |
| Store submission | 2-4 hours |
| App Store review | 1-5 days |
| **Total** | **1-2 weeks** |

---

## 🎯 Next Steps

### For Local Development
```bash
npm install
npm run dev
```

### For App Store Deployment
1. **Read:** `README_DEPLOYMENT.md` (5 min)
2. **Prepare:** Gather icons, screenshots, accounts
3. **Follow:** `DEPLOYMENT_GUIDE.md` step-by-step
4. **Reference:** Use `QUICK_START.md` for commands
5. **Build:** Create Android APK/AAB and iOS archive
6. **Submit:** Upload to respective stores

---

## 🆘 Help & Support

### First Check
1. Scroll to "Common Issues & Solutions" in `DEPLOYMENT_GUIDE.md`
2. Run `npx cap doctor` to verify setup
3. Check official docs: https://capacitorjs.com

### Common Commands
```bash
# Verify setup
npx cap doctor

# Update native code
npx cap sync

# Open Android Studio
npx cap open android

# Open Xcode
npx cap open ios

# Build web assets
npm run build

# Clean cache
cd android && ./gradlew clean
```

---

## 📚 Important Files

| File | Purpose |
|------|---------|
| `README_DEPLOYMENT.md` | Start here - overview & checklist |
| `DEPLOYMENT_GUIDE.md` | Complete step-by-step guide |
| `QUICK_START.md` | Copy-paste commands |
| `capacitor.config.ts` | App configuration |
| `package.json` | Dependencies |
| `.env` | Environment variables |

---

## ⚠️ Important Security Notes

**Never commit these to Git:**
```bash
echo "*.keystore" >> .gitignore
echo "local.properties" >> .gitignore
echo ".env.local" >> .gitignore
```

**Backup your Android keystore immediately:**
```bash
# After creating keystore, save it to a safe location
cp android/app/title-weaver.keystore ~/Backups/
```

You **cannot recover** a lost keystore - keep it safe!

---

## 🚀 Ready?

1. ✅ Have Node.js v16+ installed?
2. ✅ Read README_DEPLOYMENT.md?
3. ✅ Ready to deploy?

**Start with:**
```bash
npm install
```

Then read `README_DEPLOYMENT.md` →  
Then follow `DEPLOYMENT_GUIDE.md` →  
Then reference `QUICK_START.md`

---

## 📞 Still Need Help?

Check:
- Lovable docs: https://lovable.dev
- Capacitor docs: https://capacitorjs.com
- Android docs: https://developer.android.com
- Apple docs: https://developer.apple.com

---

**Good luck with your app! 🎉**

Questions? Everything is in the guides - they have answers to 99% of common issues!
