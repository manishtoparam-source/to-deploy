# Quick Start: GitHub + Netlify

Get your Title Weaver app live in 5 minutes! ⚡

## 🎯 5-Minute Quick Start

### 1. Fork/Clone & Install (1 min)
```bash
git clone https://github.com/your-username/title-weaver.git
cd title-weaver
npm install
```

### 2. Setup Environment (1 min)
```bash
cp .env.example .env.local
# Edit .env.local and add your Supabase & Lovable credentials
```

### 3. Test Locally (1 min)
```bash
npm run dev
# Visit http://localhost:5173
```

### 4. Push to GitHub (1 min)
```bash
git add .
git commit -m "Setup complete"
git push origin main
```

### 5. Connect Netlify (1 min)
1. Go to [Netlify](https://app.netlify.com)
2. Click "New site from Git"
3. Select your GitHub repo
4. Add environment variables in Netlify
5. Deploy!

---

## 📋 File Structure for GitHub

```
title-weaver/
├── .github/
│   └── workflows/
│       └── ci.yml                 # Automated tests
├── .env.example                   # Template for env vars
├── .gitignore                     # What to exclude from Git
├── netlify.toml                   # Netlify config
├── GITHUB_NETLIFY_SETUP.md       # Detailed setup guide
├── README.md                       # Project README
├── package.json                   # Dependencies
├── src/                           # Your code
└── ...
```

## ⚠️ Important: Never Commit

❌ Do NOT push to GitHub:
- `.env` or `.env.local`
- `node_modules/`
- `dist/` or build files
- `.idea/`, `.vscode/`

✅ These are already in `.gitignore`

## 🔄 Deployment Workflow

```
You make changes
    ↓
git push to GitHub
    ↓
GitHub Actions runs tests
    ↓
Netlify automatically deploys
    ↓
Site goes live at your URL
```

## 🚀 Your First Deployment

```bash
# Make a change to your code
# Edit src/routes/index.tsx

# Save and commit
git add .
git commit -m "Update home page"
git push origin main

# Netlify automatically:
# 1. Builds your app
# 2. Runs tests
# 3. Deploys to production
# 4. Site updates within 1-2 minutes
```

## 🔗 Important Links

After setup, you'll have:

| Link | Purpose |
|------|---------|
| `https://github.com/your-username/title-weaver` | Your code repository |
| `https://app.netlify.com/sites/your-site` | Deployment dashboard |
| `https://your-site.netlify.app` | Live website |
| `https://github.com/your-username/title-weaver/pulls` | Pull requests |

## 📖 Next Steps

1. **Read** `README.md` - Project overview
2. **Follow** `GITHUB_NETLIFY_SETUP.md` - Detailed setup
3. **Check** `netlify.toml` - Deployment config
4. **View** `.github/workflows/ci.yml` - Automated checks

## 💡 Common Commands

```bash
# Start coding
npm run dev

# Build locally
npm run build

# Check for errors
npm run lint

# Format code
npm run format

# Push to GitHub
git add .
git commit -m "Your message"
git push

# Create pull request
# Go to GitHub and click "Create Pull Request"
```

## ❓ Troubleshooting

### Site won't deploy
1. Check Netlify deploy logs
2. Verify environment variables are set
3. Check GitHub Actions workflow status

### Errors on production
1. Works locally but not on Netlify?
2. Check environment variables match locally
3. Netlify → Deploys → [build] → Deploy log

### Want to preview before deploying
1. Create a branch: `git checkout -b feature/test`
2. Make changes and push
3. Create Pull Request on GitHub
4. Netlify creates preview URL automatically
5. Test the preview
6. Merge to main when ready

---

**Ready?** Follow `GITHUB_NETLIFY_SETUP.md` for the full guide! 🚀
