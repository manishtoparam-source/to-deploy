# Title Weaver 🎬

Create stunning title cards and cinematic text overlays for your videos with ease.

[![Netlify Status](https://api.netlify.com/api/v1/badges/YOUR_NETLIFY_SITE_ID/deploy-status)](https://app.netlify.com/sites/YOUR_NETLIFY_SITE/deploys)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## ✨ Features

- 🎨 **Multiple Templates** - Pre-designed templates for different styles
- ✏️ **Easy Editor** - Intuitive drag-and-drop interface
- 🎬 **Video Export** - Download your creations as video files
- 🎯 **Custom Branding** - Create brand kits and save your styles
- 📱 **Responsive Design** - Works on desktop and mobile
- 🔐 **Secure Authentication** - User accounts with Supabase
- ☁️ **Cloud Storage** - Save and access your projects anywhere

## 🚀 Live Demo

Visit: [https://title-weaver.netlify.app](https://title-weaver.netlify.app)

## 📋 Table of Contents

- [Tech Stack](#tech-stack)
- [Installation](#installation)
- [Development](#development)
- [Deployment](#deployment)
- [Environment Variables](#environment-variables)
- [Contributing](#contributing)
- [License](#license)

## 🛠 Tech Stack

- **Frontend:** React 19 + TypeScript
- **Framework:** TanStack Start (Full-stack React framework)
- **Styling:** Tailwind CSS + Shadcn/ui Components
- **Backend/Database:** Supabase (PostgreSQL)
- **Build Tool:** Vite
- **Hosting:** Netlify (with automatic deployments)
- **Authentication:** Lovable Cloud Auth + Supabase Auth

## 📦 Installation

### Prerequisites

- Node.js 18+ ([download](https://nodejs.org))
- npm 9+ (comes with Node.js)
- Git ([download](https://git-scm.com))

### Setup

1. **Clone the repository**
```bash
git clone https://github.com/your-username/title-weaver.git
cd title-weaver
```

2. **Install dependencies**
```bash
npm install
```

3. **Set up environment variables**
```bash
cp .env.example .env.local
```

Edit `.env.local` and add your credentials:
```env
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
VITE_LOVABLE_API_KEY=your_lovable_api_key
```

4. **Start development server**
```bash
npm run dev
```

Visit: `http://localhost:5173`

## 💻 Development

### Available Commands

```bash
# Start dev server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview

# Lint code
npm run lint

# Format code
npm run format
```

### Project Structure

```
src/
├── components/          # React components
│   ├── editor/         # Title editor component
│   ├── title-card/     # Preview component
│   ├── ui/             # Shadcn UI components
│   └── branding/       # Branding components
├── routes/             # App pages (TanStack Router)
│   ├── index.tsx       # Home page
│   ├── auth.tsx        # Auth page
│   └── _authenticated/ # Protected routes
├── lib/                # Utilities & helpers
│   ├── projects.functions.ts     # Project management
│   ├── render-video.ts           # Video rendering
│   ├── templates.ts              # Template data
│   └── ...
├── integrations/       # External integrations
│   ├── supabase/      # Database client
│   └── lovable/       # Lovable integration
├── assets/            # Images, templates, fonts
├── styles.css         # Global styles
└── router.tsx         # Route configuration
```

### Database

Supabase migrations are in `supabase/migrations/`. They're applied automatically.

To view schema:
1. Go to [Supabase Dashboard](https://app.supabase.com)
2. Select your project
3. Go to SQL Editor

## 🚀 Deployment

### Automatic Deployment with Netlify

This project is configured for automatic deployments on push to `main` branch.

#### Setup Steps

1. **Push to GitHub**
```bash
git add .
git commit -m "Initial commit"
git push origin main
```

2. **Connect to Netlify**
   - Go to [Netlify](https://app.netlify.com)
   - Click "New site from Git"
   - Select GitHub, authorize, and choose this repository
   - Click "Deploy site"

3. **Set Environment Variables**
   - In Netlify dashboard: Site Settings → Build & Deploy → Environment
   - Add these environment variables:
     ```
     VITE_SUPABASE_URL=your_supabase_url
     VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
     VITE_LOVABLE_API_KEY=your_lovable_api_key
     ```

4. **Verify Deployment**
   - Netlify will automatically build and deploy
   - Check: Netlify → Deploys tab for status
   - Your site will be live at: `https://your-site.netlify.app`

### Build Configuration

Build settings are in `netlify.toml`:
- **Build command:** `npm run build`
- **Publish directory:** `dist`
- **Node version:** 20

### Manual Deploy (for testing)

```bash
npm run build
npm run preview
```

## 🔐 Environment Variables

### Required Variables

```env
# Supabase
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your_anon_key_here

# Lovable API (for rendering)
VITE_LOVABLE_API_KEY=your_lovable_key_here
```

### Optional Variables

```env
# API URLs
VITE_API_URL=https://api.example.com

# Feature flags
VITE_ENABLE_BETA_FEATURES=false
```

**Never commit `.env` or `.env.local` to Git!** Use `.env.example` instead.

## 👥 Contributing

We welcome contributions! Here's how:

1. **Fork the repository**
2. **Create a feature branch**
   ```bash
   git checkout -b feature/amazing-feature
   ```
3. **Make your changes**
4. **Commit with clear messages**
   ```bash
   git commit -m "Add amazing feature"
   ```
5. **Push to your fork**
   ```bash
   git push origin feature/amazing-feature
   ```
6. **Open a Pull Request**

### Code Standards

- Write clean, readable code
- Add comments for complex logic
- Test your changes locally
- Follow the existing code style
- Run `npm run lint` before committing

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Support

- 📖 [Documentation](./docs)
- 🐛 [Report Bugs](https://github.com/your-username/title-weaver/issues)
- 💡 [Request Features](https://github.com/your-username/title-weaver/discussions)
- 📧 [Email Support](mailto:support@titleweaver.com)

## 📊 Project Status

- ✅ MVP Complete
- ✅ Netlify Deployment
- 🚧 Mobile App (Capacitor)
- 📅 AI-powered text suggestions (Coming soon)
- 📅 Collaboration features (Coming soon)

## 🙏 Acknowledgments

- Built with [TanStack Start](https://tanstack.com/start)
- UI Components from [Shadcn/ui](https://ui.shadcn.com)
- Powered by [Supabase](https://supabase.com)
- Created with [Lovable](https://lovable.dev)

---

**Made with ❤️ by the Title Weaver team**

[⬆ back to top](#title-weaver-)
