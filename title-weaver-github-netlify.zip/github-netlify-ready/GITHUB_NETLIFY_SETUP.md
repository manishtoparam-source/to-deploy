# GitHub + Netlify Setup Guide

This guide walks you through setting up your Title Weaver repository on GitHub and connecting it to Netlify for automatic deployments.

## 📋 Prerequisites

- GitHub account ([sign up free](https://github.com/signup))
- Netlify account ([sign up free](https://app.netlify.com/signup))
- Git installed on your computer
- Supabase project created
- Lovable API key

## 🚀 Step-by-Step Setup

### Step 1: Create GitHub Repository

1. **Create new repository on GitHub**
   - Go to [github.com/new](https://github.com/new)
   - Repository name: `title-weaver`
   - Description: "Create stunning title cards and cinematic text overlays"
   - Choose: Public (for open source) or Private
   - Click "Create repository"

2. **Initialize local repository**
   ```bash
   cd title-weaver
   git init
   git add .
   git commit -m "Initial commit: Title Weaver app"
   ```

3. **Connect to GitHub**
   ```bash
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/title-weaver.git
   git push -u origin main
   ```

### Step 2: Configure Environment Variables

1. **Create `.env.local` from `.env.example`**
   ```bash
   cp .env.example .env.local
   ```

2. **Fill in your credentials**
   ```env
   VITE_SUPABASE_URL=your_supabase_url
   VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
   VITE_LOVABLE_API_KEY=your_lovable_api_key
   ```

3. **Verify `.env.local` is in `.gitignore`** (it should be)
   ```bash
   grep ".env.local" .gitignore  # Should return: .env.local
   ```

### Step 3: Connect to Netlify

1. **Go to Netlify**
   - Visit [app.netlify.com](https://app.netlify.com)
   - Sign in with GitHub (recommended)

2. **Create new site**
   - Click "New site from Git"
   - Select "GitHub" as provider
   - Authorize Netlify to access your GitHub
   - Select your `title-weaver` repository

3. **Configure build settings**
   - Build command: `npm run build`
   - Publish directory: `dist`
   - Click "Deploy site"

### Step 4: Set Environment Variables in Netlify

1. **Go to Site Settings**
   - Netlify dashboard → Your site → Site settings

2. **Add Build & Deploy → Environment**
   - Click "Edit variables"
   - Add each variable:

   | Key | Value |
   |-----|-------|
   | `VITE_SUPABASE_URL` | Your Supabase URL |
   | `VITE_SUPABASE_ANON_KEY` | Your Supabase anon key |
   | `VITE_LOVABLE_API_KEY` | Your Lovable API key |

3. **Save and redeploy**
   - Netlify will automatically rebuild with new variables

### Step 5: Verify Deployment

1. **Check build status**
   - Netlify → Deploys tab
   - Wait for "Published" status
   - Click the deploy to view live site

2. **Test the site**
   - Click your Netlify domain (e.g., `https://title-weaver-123.netlify.app`)
   - Test all features work correctly
   - Check browser console for errors

## 🔄 Automatic Deployments

Once connected, every push to `main` branch will:

1. ✅ Trigger automatic build
2. ✅ Run tests/linting
3. ✅ Build production assets
4. ✅ Deploy to live URL
5. ✅ Generate deploy preview for PRs

### Deployment Statuses

- 🟢 **Published** - Live and ready
- 🟡 **Building** - In progress
- 🔴 **Failed** - Check build logs
- 🔵 **Draft** - Preview not yet live

## 📝 Git Workflow

### Normal Development

```bash
# Create feature branch
git checkout -b feature/your-feature

# Make changes
# ... edit files ...

# Commit changes
git add .
git commit -m "Add your feature description"

# Push to GitHub
git push origin feature/your-feature

# Create Pull Request on GitHub
# Netlify will automatically create preview deployment
```

### Merge to Main

```bash
# After PR review and approval
# Merge via GitHub UI

# Pull latest main
git checkout main
git pull origin main
```

## 🆘 Common Issues & Solutions

### Build Fails on Netlify (but works locally)

**Issue:** Environment variables are missing
```
Error: Cannot find module '@supabase/...'
```

**Solution:**
1. Check all environment variables are set in Netlify
2. Verify variable names match your code
3. Redeploy after adding variables
4. Check build logs: Netlify → Deploys → [build] → Deploy log

### Site Shows 404 on Netlify

**Issue:** SPA routing not configured
**Solution:** Already fixed in `netlify.toml` - should work automatically

### Preview Deployment Not Updating

**Issue:** Cache not clearing
**Solution:**
1. Netlify → Deploys → [your PR] → Retry deploy
2. Or manually trigger rebuild

### Slow Build Times

**Issue:** Dependencies installing
**Solution:**
1. Check for large dependencies in `package.json`
2. Consider using `npm ci` instead of `npm install`
3. Netlify caches node_modules automatically

## 📊 Monitoring Deployments

### View Build Logs

```
Netlify → Deploys → [click deploy] → Deploy log
```

Look for:
- Build command output
- npm install output
- Build errors/warnings
- Deployment size

### View Site Performance

```
Netlify → Analytics → Site analytics
```

Track:
- Unique visitors
- Page views
- Bandwidth usage
- Deploy frequency

## 🔒 Security Checklist

- ✅ Environment variables set in Netlify (not in code)
- ✅ `.env.local` in `.gitignore`
- ✅ No secrets in commit messages
- ✅ GitHub branch protection enabled
- ✅ Supabase Row Level Security configured
- ✅ CORS headers configured in `netlify.toml`

## 🚀 Advanced: Custom Domain

1. **Buy domain** (GoDaddy, Namecheap, etc.)
2. **Netlify → Domain settings → Add custom domain**
3. **Update DNS** with Netlify nameservers
4. **Wait 24-48 hours** for propagation

## 📚 Resources

- Netlify Docs: https://docs.netlify.com
- GitHub Docs: https://docs.github.com
- Git Guide: https://git-scm.com/book/en/v2
- Supabase Docs: https://supabase.com/docs

## ✅ Checklist

- [ ] GitHub repository created
- [ ] Code pushed to GitHub
- [ ] Netlify site created from GitHub
- [ ] Environment variables added to Netlify
- [ ] First deployment successful
- [ ] Site is live and working
- [ ] `.env.local` is in `.gitignore`
- [ ] `netlify.toml` is configured correctly

---

**All set!** Your site will now automatically deploy whenever you push to GitHub. 🎉
